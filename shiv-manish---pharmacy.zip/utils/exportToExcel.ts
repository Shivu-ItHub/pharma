
// Ensure XLSX is globally available from index.html's CDN link
declare var XLSX: any;

export interface SheetData {
  sheetName: string;
  data: any[]; // Array of objects
  columnWidths?: { wch: number }[]; // Optional: column widths in characters
}

export const exportToExcel = (fileName: string, sheets: SheetData[]): void => {
  if (typeof XLSX === 'undefined') {
    console.error("XLSX library is not loaded. Cannot export to Excel.");
    alert("Error: Excel export functionality is not available. Please check your internet connection or contact support.");
    return;
  }

  try {
    const wb = XLSX.utils.book_new();
    sheets.forEach(sheetInfo => {
      const ws = XLSX.utils.json_to_sheet(sheetInfo.data);
      if (sheetInfo.columnWidths) {
        ws['!cols'] = sheetInfo.columnWidths;
      }
      XLSX.utils.book_append_sheet(wb, ws, sheetInfo.sheetName);
    });
    XLSX.writeFile(wb, `${fileName}.xlsx`);
  } catch (error) {
    console.error("Error exporting to Excel:", error);
    alert(`An error occurred while exporting to Excel: ${error.message}`);
  }
};
