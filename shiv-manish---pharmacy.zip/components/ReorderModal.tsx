import React, { useState, useEffect } from 'react';
import { Medicine, NewBatchInfo } from '../types'; 
import Modal from './Modal';
import Button from './Button';
import InputField from './InputField';
import { SendIcon } from '../constants';
import { format } from 'date-fns';

interface ReorderModalProps {
  isOpen: boolean;
  onClose: () => void;
  medicine: Medicine | null;
  onConfirmReorder: (medicine: Medicine, quantity: number, batchDetails: NewBatchInfo) => void; 
}

const initialBatchDetailsState: NewBatchInfo = {
  batchNumber: '',
  manufacturingDate: format(new Date(), 'yyyy-MM-dd'),
  expiryDate: '',
  purchasePrice: 0,
  salePrice: 0,
};

const ReorderModal: React.FC<ReorderModalProps> = ({ isOpen, onClose, medicine, onConfirmReorder }) => {
  const [quantity, setQuantity] = useState<number>(1);
  const [batchDetails, setBatchDetails] = useState<NewBatchInfo>(initialBatchDetailsState);

  useEffect(() => {
    if (medicine && isOpen) {
      const suggestedQuantity = Math.max(10, (medicine.lowStockThreshold || 10) * 2 - medicine.quantityInStock);
      setQuantity(Math.max(1, suggestedQuantity));
      setBatchDetails({
        batchNumber: '', 
        manufacturingDate: format(new Date(), 'yyyy-MM-dd'),
        expiryDate: '', 
        purchasePrice: medicine.purchasePrice, 
        salePrice: medicine.salePrice,       
      });
    } else if (!isOpen) {
      setQuantity(1);
      setBatchDetails(initialBatchDetailsState);
    }
  }, [medicine, isOpen]);

  if (!isOpen || !medicine) return null;

  const handleBatchInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    setBatchDetails(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : value,
    }));
  };

  const handleConfirm = () => {
    if (quantity <= 0) {
      alert("Re-order quantity must be greater than zero.");
      return;
    }
    if (!batchDetails.batchNumber || !batchDetails.manufacturingDate || !batchDetails.expiryDate) {
        alert("Please fill in all new batch details (Batch No, Mfg Date, Exp Date).");
        return;
    }
    if (new Date(batchDetails.expiryDate) <= new Date(batchDetails.manufacturingDate)) {
        alert("Expiry date must be after manufacturing date.");
        return;
    }
    if (batchDetails.purchasePrice <= 0 || batchDetails.salePrice <= 0) {
        alert("Purchase and Sale prices must be greater than zero.");
        return;
    }
    if (batchDetails.salePrice < batchDetails.purchasePrice) {
        if (!window.confirm("Warning: Sale price is less than purchase price. Continue?")) {
            return;
        }
    }

    onConfirmReorder(medicine, quantity, batchDetails);
  };

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose} 
      title={`Re-order: ${medicine.name}`}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button onClick={handleConfirm} leftIcon={<SendIcon className="w-5 h-5" />}>Confirm Re-order</Button>
        </>
      }
    >
      <div className="space-y-4">
        <p><strong>Medicine:</strong> {medicine.name}</p>
        <p><strong>Current Batch:</strong> {medicine.batchNumber} (Exp: {format(new Date(medicine.expiryDate), 'P')})</p>
        <p><strong>Current Stock:</strong> <span className="font-semibold text-red-600">{medicine.quantityInStock}</span> units</p>
        <p><strong>Supplier:</strong> {medicine.supplier || 'N/A'}</p>
        
        <InputField
          label="Quantity to Re-order"
          type="number"
          name="reorderQuantity"
          value={quantity}
          onChange={(e) => setQuantity(parseInt(e.target.value, 10) || 0)}
          min="1"
          required
          containerClassName="mt-4"
        />
        <hr className="my-3"/>
        <h4 className="text-md font-semibold">New Batch Details for this Re-order:</h4>
        <InputField label="New Batch Number" name="batchNumber" value={batchDetails.batchNumber} onChange={handleBatchInputChange} required />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InputField label="New Manufacturing Date" name="manufacturingDate" type="date" value={batchDetails.manufacturingDate} onChange={handleBatchInputChange} required />
            <InputField label="New Expiry Date" name="expiryDate" type="date" value={batchDetails.expiryDate} onChange={handleBatchInputChange} required />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InputField label="Purchase Price (per unit)" name="purchasePrice" type="number" step="0.01" value={batchDetails.purchasePrice} onChange={handleBatchInputChange} required />
            <InputField label="Sale Price (per unit)" name="salePrice" type="number" step="0.01" value={batchDetails.salePrice} onChange={handleBatchInputChange} required />
        </div>
      </div>
    </Modal>
  );
};

export default ReorderModal;