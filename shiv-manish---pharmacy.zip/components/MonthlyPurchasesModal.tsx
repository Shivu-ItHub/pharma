import React from 'react';
import { PurchaseRecord, TableColumn } from '../types';
import Modal from './Modal';
import Table from './Table';
import { format } from 'date-fns';
import { ShoppingBagIcon } from '../constants';

interface MonthlyPurchasesModalProps {
  isOpen: boolean;
  onClose: () => void;
  purchaseRecords: PurchaseRecord[];
  monthName: string;
}

const MonthlyPurchasesModal: React.FC<MonthlyPurchasesModalProps> = ({ isOpen, onClose, purchaseRecords, monthName }) => {
  const purchaseColumns: TableColumn<PurchaseRecord>[] = [
    { key: 'medicineName', header: 'Medicine' },
    { key: 'batchNumber', header: 'Batch No.' },
    { key: 'supplier', header: 'Supplier', render: (item) => item.supplier || 'N/A' },
    { key: 'quantityPurchased', header: 'Qty Purchased' },
    { key: 'purchasePricePerUnit', header: 'Unit Cost', render: (item) => `$${item.purchasePricePerUnit.toFixed(2)}` },
    { key: 'totalPurchaseCost', header: 'Total Cost', render: (item) => `$${item.totalPurchaseCost.toFixed(2)}` },
    { key: 'purchaseDate', header: 'Purchase Date', render: (item) => format(new Date(item.purchaseDate), 'P p') },
    { key: 'notes', header: 'Notes', render: (item) => item.notes || 'N/A'},
  ];

  const totalPurchaseValue = purchaseRecords.reduce((sum, pr) => sum + pr.totalPurchaseCost, 0);

  return (
    <Modal 
        isOpen={isOpen} 
        onClose={onClose} 
        title={
            <div className="flex items-center">
                <ShoppingBagIcon className="w-6 h-6 mr-2 text-primary-600"/>
                {`Purchase Details for ${monthName}`}
            </div>
        }
    >
      <div className="space-y-4">
        <div className="text-right font-semibold text-gray-700">
            Total Purchases for {monthName}: ${totalPurchaseValue.toFixed(2)}
        </div>
        <Table 
            columns={purchaseColumns} 
            data={purchaseRecords} 
            keyExtractor={(item) => item.id} 
            emptyStateMessage="No purchases recorded for this month."
        />
      </div>
    </Modal>
  );
};

export default MonthlyPurchasesModal;
