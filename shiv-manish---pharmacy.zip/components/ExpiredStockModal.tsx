
import React, { useState, useEffect } from 'react';
import { Medicine, NewBatchDetails } from '../types';
import Modal from './Modal';
import Button from './Button';
import InputField from './InputField';
import ConfirmationDialog from './ConfirmationDialog';
import { ArchiveBoxArrowDownIcon, ReplaceIcon } from '../constants';
import { format } from 'date-fns';

interface ExpiredStockModalProps {
  isOpen: boolean;
  onClose: () => void;
  medicine: Medicine | null;
  onDisposeStock: (medicineId: string) => void;
  onReplaceBatch: (medicineId: string, newBatchDetails: NewBatchDetails) => void;
}

// Fix: Align property names with NewBatchDetails type
const initialNewBatchFormState: NewBatchDetails = {
  batchNumber: '',
  manufacturingDate: '', // Will be defaulted to today if medicine exists
  expiryDate: '',
  purchasePrice: 0,
  salePrice: 0,
  newQuantityInStock: 0,
};

const ExpiredStockModal: React.FC<ExpiredStockModalProps> = ({ 
  isOpen, 
  onClose, 
  medicine, 
  onDisposeStock, 
  onReplaceBatch 
}) => {
  const [view, setView] = useState<'options' | 'disposeConfirm' | 'replaceForm'>('options');
  const [newBatchForm, setNewBatchForm] = useState<NewBatchDetails>(initialNewBatchFormState);

  useEffect(() => {
    if (isOpen) {
      setView('options'); // Reset view when modal opens
      if (medicine) { // Pre-fill some fields for convenience if replacing
        // Fix: Align property names with NewBatchDetails type
        setNewBatchForm({
          batchNumber: '', // Requires new batch number
          manufacturingDate: format(new Date(), 'yyyy-MM-dd'), // Default to today for new batch
          expiryDate: '',    // Requires new expiry date
          purchasePrice: medicine.purchasePrice, // Default from current medicine
          salePrice: medicine.salePrice,       // Default from current medicine
          newQuantityInStock: 0, // Start with 0 for new stock
        });
      } else {
        setNewBatchForm(initialNewBatchFormState);
      }
    }
  }, [isOpen, medicine]);

  if (!isOpen || !medicine) return null;

  const handleNewBatchInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    setNewBatchForm(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : value,
    }));
  };

  const handleConfirmDispose = () => {
    onDisposeStock(medicine.id);
    onClose();
  };

  const handleConfirmReplace = (e: React.FormEvent) => {
    e.preventDefault();
    // Basic validation
    // Fix: Align property names with NewBatchDetails type
    if (!newBatchForm.batchNumber || !newBatchForm.manufacturingDate || !newBatchForm.expiryDate || newBatchForm.newQuantityInStock <= 0) {
        alert("Please fill all new batch details (Batch No, Mfg Date, Exp Date) and ensure quantity is positive.");
        return;
    }
    // Fix: Align property names with NewBatchDetails type
    if (new Date(newBatchForm.expiryDate) <= new Date(newBatchForm.manufacturingDate)) {
        alert("Expiry date must be after manufacturing date.");
        return;
    }
    // Fix: Align property names with NewBatchDetails type
    if (new Date(newBatchForm.expiryDate) <= new Date()) {
        alert("New expiry date must be in the future.");
        return;
    }

    onReplaceBatch(medicine.id, newBatchForm);
    onClose();
  };
  
  const medicineNameDisplay = `${medicine.name} (Batch: ${medicine.batchNumber})`;

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose} 
      title={view === 'replaceForm' ? `Replace Batch: ${medicineNameDisplay}` : `Handle Expired Stock: ${medicineNameDisplay}`}
    >
      <div className="space-y-4">
        <div className="p-3 bg-red-50 border border-red-200 rounded-md">
            <p><strong>Medicine:</strong> {medicine.name}</p>
            <p><strong>Batch:</strong> {medicine.batchNumber}</p>
            <p><strong>Expired On:</strong> {format(new Date(medicine.expiryDate), 'P')}</p>
            <p><strong>Current Stock (Expired):</strong> <span className="font-semibold text-red-700">{medicine.quantityInStock}</span> units</p>
        </div>

        {view === 'options' && (
          <div className="space-y-3 pt-4">
            <p className="text-sm text-gray-600">Choose an action for this expired batch:</p>
            <Button 
              variant="danger" 
              onClick={() => setView('disposeConfirm')} 
              leftIcon={<ArchiveBoxArrowDownIcon className="w-5 h-5" />}
              className="w-full"
            >
              Dispose Stock & Set Quantity to Zero
            </Button>
            <Button 
              variant="primary" 
              onClick={() => setView('replaceForm')} 
              leftIcon={<ReplaceIcon className="w-5 h-5" />}
              className="w-full"
            >
              Replace with New Batch (Clears Old Stock)
            </Button>
            <Button variant="secondary" onClick={onClose} className="w-full mt-2">Cancel</Button>
          </div>
        )}

        {view === 'disposeConfirm' && (
           <ConfirmationDialog
            isOpen={true} // This modal is already open, so this controls the confirmation part
            onClose={() => setView('options')}
            onConfirm={handleConfirmDispose}
            title="Confirm Disposal"
            message={`Are you sure you want to dispose of all ${medicine.quantityInStock} units of ${medicineNameDisplay}? This will set its stock quantity to 0. This action cannot be directly undone (though stock can be manually adjusted later).`}
            confirmButtonText="Yes, Dispose Stock"
            cancelButtonText="Back to Options"
          />
        )}

        {view === 'replaceForm' && (
          <form onSubmit={handleConfirmReplace} className="space-y-4 pt-4">
            <h4 className="text-md font-semibold text-gray-700 border-b pb-2">Enter New Batch Details:</h4>
            {/* Fix: Align InputField name and value access with NewBatchDetails type */}
            <InputField label="New Batch Number" name="batchNumber" value={newBatchForm.batchNumber} onChange={handleNewBatchInputChange} required />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Fix: Align InputField name and value access with NewBatchDetails type */}
              <InputField label="New Manufacturing Date" name="manufacturingDate" type="date" value={newBatchForm.manufacturingDate} onChange={handleNewBatchInputChange} required />
              {/* Fix: Align InputField name and value access with NewBatchDetails type */}
              <InputField label="New Expiry Date" name="expiryDate" type="date" value={newBatchForm.expiryDate} onChange={handleNewBatchInputChange} required />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Fix: Align InputField name and value access with NewBatchDetails type */}
              <InputField label="New Purchase Price" name="purchasePrice" type="number" step="0.01" value={newBatchForm.purchasePrice} onChange={handleNewBatchInputChange} required />
              {/* Fix: Align InputField name and value access with NewBatchDetails type */}
              <InputField label="New Sale Price" name="salePrice" type="number" step="0.01" value={newBatchForm.salePrice} onChange={handleNewBatchInputChange} required />
              <InputField label="New Quantity in Stock" name="newQuantityInStock" type="number" value={newBatchForm.newQuantityInStock} onChange={handleNewBatchInputChange} required min="1" />
            </div>
            <p className="text-xs text-gray-500 mt-1">Note: The existing stock of the expired batch ({medicine.quantityInStock} units) will be cleared and replaced by this new quantity.</p>
            <div className="flex justify-end space-x-2 pt-3">
              <Button type="button" variant="secondary" onClick={() => setView('options')}>Back to Options</Button>
              <Button type="submit" leftIcon={<ReplaceIcon className="w-5 h-5"/>}>Confirm & Replace Batch</Button>
            </div>
          </form>
        )}
      </div>
    </Modal>
  );
};

export default ExpiredStockModal;
