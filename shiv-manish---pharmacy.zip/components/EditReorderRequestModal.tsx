import React, { useState, useEffect } from 'react';
import { ReorderRequest, NewBatchInfo, EditReorderRequestPayload } from '../types';
import Modal from './Modal';
import Button from './Button';
import InputField from './InputField';
import { PencilIcon } from '../constants';
import { format } from 'date-fns';

interface EditReorderRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  request: ReorderRequest | null;
  onConfirmEdit: (payload: EditReorderRequestPayload) => void;
}

const EditReorderRequestModal: React.FC<EditReorderRequestModalProps> = ({ 
    isOpen, 
    onClose, 
    request, 
    onConfirmEdit 
}) => {
  const [quantityOrdered, setQuantityOrdered] = useState<number>(0);
  const [batchDetails, setBatchDetails] = useState<NewBatchInfo>({
    batchNumber: '',
    manufacturingDate: '',
    expiryDate: '',
    purchasePrice: 0,
    salePrice: 0,
  });
  const [adminNotes, setAdminNotes] = useState<string>('');

  useEffect(() => {
    if (request && isOpen) {
      setQuantityOrdered(request.quantityOrdered);
      setBatchDetails(request.newBatchDetails || {
        batchNumber: '',
        manufacturingDate: format(new Date(), 'yyyy-MM-dd'),
        expiryDate: '',
        purchasePrice: 0,
        salePrice: 0,
      });
      setAdminNotes(request.adminNotes || '');
    }
  }, [request, isOpen]);

  if (!isOpen || !request) return null;

  const handleBatchInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    setBatchDetails(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : value,
    }));
  };

  const handleConfirm = () => {
    if (quantityOrdered <= 0) {
      alert("Re-order quantity must be greater than zero.");
      return;
    }
    if (!batchDetails.batchNumber || !batchDetails.manufacturingDate || !batchDetails.expiryDate) {
        alert("Please fill in all new batch details (Batch No, Mfg Date, Exp Date).");
        return;
    }
    if (new Date(batchDetails.expiryDate) <= new Date(batchDetails.manufacturingDate)) {
        alert("Expiry date must be after manufacturing date.");
        return;
    }
     if (batchDetails.purchasePrice <= 0 || batchDetails.salePrice <= 0) {
        alert("Purchase and Sale prices must be greater than zero.");
        return;
    }
     if (batchDetails.salePrice < batchDetails.purchasePrice) {
        if (!window.confirm("Warning: Sale price is less than purchase price. Continue?")) {
            return;
        }
    }

    onConfirmEdit({
        requestId: request.id,
        updatedDetails: {
            quantityOrdered,
            newBatchDetails: batchDetails,
            adminNotes: adminNotes || undefined, // Send undefined if empty to not overwrite with empty string if not intended
        }
    });
    onClose();
  };

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose} 
      title={`Edit Re-order: ${request.medicineName} (ID: ${request.id})`}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button onClick={handleConfirm} leftIcon={<PencilIcon className="w-5 h-5" />}>Save Changes</Button>
        </>
      }
    >
      <div className="space-y-4">
        <p><strong>Medicine:</strong> {request.medicineName}</p>
        <p><strong>Current Status:</strong> <span className="font-semibold text-yellow-600">{request.status}</span></p>
        
        <InputField
          label="Quantity to Re-order"
          type="number"
          name="quantityOrdered"
          value={quantityOrdered}
          onChange={(e) => setQuantityOrdered(parseInt(e.target.value, 10) || 0)}
          min="1"
          required
          containerClassName="mt-4"
        />
        <hr className="my-3"/>
        <h4 className="text-md font-semibold">Batch Details for this Re-order:</h4>
        <InputField label="Batch Number" name="batchNumber" value={batchDetails.batchNumber} onChange={handleBatchInputChange} required />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InputField label="Manufacturing Date" name="manufacturingDate" type="date" value={batchDetails.manufacturingDate} onChange={handleBatchInputChange} required />
            <InputField label="Expiry Date" name="expiryDate" type="date" value={batchDetails.expiryDate} onChange={handleBatchInputChange} required />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InputField label="Purchase Price (per unit)" name="purchasePrice" type="number" step="0.01" value={batchDetails.purchasePrice} onChange={handleBatchInputChange} required />
            <InputField label="Sale Price (per unit)" name="salePrice" type="number" step="0.01" value={batchDetails.salePrice} onChange={handleBatchInputChange} required />
        </div>
         <InputField 
            label="Admin Notes (Optional)" 
            name="adminNotes" 
            value={adminNotes} 
            onChange={(e) => setAdminNotes(e.target.value)} 
            placeholder="Reason for edit, supplier communication, etc."
        />
      </div>
    </Modal>
  );
};

export default EditReorderRequestModal;