
import React from 'react';
import { NavLink } from 'react-router-dom';
import { NAV_ITEMS, APP_NAME } from '../constants';
import { useAppContext } from '../contexts/AppContext';
import { PillIcon } from '../constants'; // Using PillIcon for logo

const Sidebar: React.FC = () => {
  const { state } = useAppContext();
  const { currentUser } = state;

  return (
    <div className="w-64 bg-primary-800 text-primary-100 flex flex-col">
      <div className="h-20 flex items-center justify-center border-b border-primary-700">
        <PillIcon className="w-10 h-10 mr-2 text-white" />
        <h1 className="text-2xl font-semibold text-white">{APP_NAME}</h1>
      </div>
      <nav className="flex-1 mt-4">
        {NAV_ITEMS.map((item) => 
          (currentUser && item.roles.includes(currentUser.role)) && (
            <NavLink
              key={item.name}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center px-6 py-3 hover:bg-primary-700 transition-colors duration-200 ${
                  isActive ? 'bg-primary-700 border-l-4 border-primary-500' : ''
                }`
              }
            >
              {item.icon && <span className="mr-3">{item.icon}</span>}
              {item.name}
            </NavLink>
          )
        )}
      </nav>
      <div className="p-4 border-t border-primary-700 text-center text-sm">
        © {new Date().getFullYear()} {APP_NAME}
      </div>
    </div>
  );
};

export default Sidebar;
