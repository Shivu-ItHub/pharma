
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../contexts/AppContext';
import { LogoutIcon } from '../constants';

const Header: React.FC = () => {
  const { state, dispatch } = useAppContext();
  const { currentUser } = state;
  const navigate = useNavigate();

  const handleLogout = () => {
    dispatch({ type: 'LOGOUT' });
    navigate('/login');
  };

  return (
    <header className="h-16 bg-white shadow-md flex items-center justify-between px-6">
      <div>
        {/* Placeholder for breadcrumbs or page title if needed */}
        <h2 className="text-xl font-semibold text-gray-700">Pharmacy Management</h2>
      </div>
      <div className="flex items-center">
        {currentUser && (
          <div className="mr-4">
            <span className="text-gray-600">Welcome, </span>
            <span className="font-semibold text-primary-600">{currentUser.name} ({currentUser.role})</span>
          </div>
        )}
        <button
          onClick={handleLogout}
          className="flex items-center text-gray-600 hover:text-primary-600 transition-colors duration-200"
          title="Logout"
        >
          <LogoutIcon className="w-6 h-6 mr-1" />
          Logout
        </button>
      </div>
    </header>
  );
};

export default Header;
