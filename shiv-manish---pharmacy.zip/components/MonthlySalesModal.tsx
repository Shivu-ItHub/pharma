import React from 'react';
import { Bill, TableColumn } from '../types';
import Modal from './Modal';
import Table from './Table';
import { format } from 'date-fns';
import { ShoppingCartIcon } from '../constants';

interface MonthlySalesModalProps {
  isOpen: boolean;
  onClose: () => void;
  bills: Bill[];
  monthName: string;
}

const MonthlySalesModal: React.FC<MonthlySalesModalProps> = ({ isOpen, onClose, bills, monthName }) => {
  const salesColumns: TableColumn<Bill>[] = [
    { key: 'billNumber', header: 'Bill No.' },
    { key: 'date', header: 'Date', render: (item) => format(new Date(item.date), 'P p') },
    { key: 'customerName', header: 'Customer', render: (item) => item.customerName || 'Walk-in' },
    { key: 'items', header: 'Items Count', render: (item) => item.items.length },
    { key: 'finalAmount', header: 'Final Amount', render: (item) => `$${item.finalAmount.toFixed(2)}` },
    { key: 'billedByUserName', header: 'Billed By' },
  ];

  const totalSalesValue = bills.reduce((sum, bill) => sum + bill.finalAmount, 0);

  return (
    <Modal 
        isOpen={isOpen} 
        onClose={onClose} 
        title={
            <div className="flex items-center">
                <ShoppingCartIcon className="w-6 h-6 mr-2 text-primary-600"/>
                {`Sales Details for ${monthName}`}
            </div>
        }
    >
      <div className="space-y-4">
        <div className="text-right font-semibold text-gray-700">
            Total Sales for {monthName}: ${totalSalesValue.toFixed(2)}
        </div>
        <Table 
            columns={salesColumns} 
            data={bills} 
            keyExtractor={(item) => item.id} 
            emptyStateMessage="No sales recorded for this month."
        />
      </div>
    </Modal>
  );
};

export default MonthlySalesModal;
