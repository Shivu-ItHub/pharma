import React from 'react';
import { Link } from 'react-router-dom';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  colorClass: string;
  tooltip?: string;
  linkTo?: string;
  onClick?: () => void; // Added onClick prop
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon, colorClass, tooltip, linkTo, onClick }) => {
  const cardContent = (
    <div className={`p-3 rounded-full bg-opacity-20 bg-white`}>
      {icon}
    </div>
  );

  const textContent = (
    <div>
      <p className="text-sm font-medium text-gray-100 uppercase">{title}</p>
      <p className="text-3xl font-bold text-white">{value}</p>
    </div>
  );

  const baseClasses = `bg-white p-6 rounded-lg shadow-lg flex items-center space-x-4 ${colorClass}`;
  
  if (onClick) {
    return (
      <button
        onClick={onClick}
        className={`${baseClasses} w-full text-left transition-opacity hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-white`}
        title={tooltip || title}
      >
        {cardContent}
        {textContent}
      </button>
    );
  }

  if (linkTo) {
    return (
      <Link to={linkTo} className={`${baseClasses} transition-opacity hover:opacity-90`} title={tooltip || title}>
        {cardContent}
        {textContent}
      </Link>
    );
  }

  return (
    <div className={baseClasses} title={tooltip || title}>
      {cardContent}
      {textContent}
    </div>
  );
};

export default StatCard;
