
import React, { ReactNode } from 'react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children, footer }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 no-print"> {/* Backdrop is no-print */}
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg max-h-[90vh] flex flex-col no-print"> {/* Main modal container also no-print */}
        <div className="flex justify-between items-center p-4 border-b no-print"> {/* Modal header is no-print */}
          <h3 className="text-xl font-semibold text-gray-800">{title}</h3>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 text-2xl"
            aria-label="Close modal"
          >
            &times;
          </button>
        </div>
        <div className="p-6 overflow-y-auto">
          {/* This is where .printable-area will be if children contains it */}
          {children}
        </div>
        {footer && (
          <div className="p-4 border-t flex justify-end space-x-2 no-print"> {/* Modal footer is no-print */}
            {footer}
          </div>
        )}
      </div>
    </div>
  );
};

export default Modal;