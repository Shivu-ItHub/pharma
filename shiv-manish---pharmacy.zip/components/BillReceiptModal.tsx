import React from 'react';
import { Bill, BillItem } from '../types';
import Modal from './Modal';
import Button from './Button';
import { PrinterIcon, APP_NAME } from '../constants'; // Import APP_NAME
// Fix: Replaced parseISO with new Date() due to 'no exported member' error.
import { format } from 'date-fns';

interface BillReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  bill: Bill | null;
}

const BillReceiptModal: React.FC<BillReceiptModalProps> = ({ isOpen, onClose, bill }) => {
  if (!bill) return null;

  const handlePrint = () => {
    window.focus(); // Attempt to bring the window to the foreground
    window.print();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Receipt: ${bill.billNumber}`} footer={
      <div className="no-print"> {/* Ensure footer buttons themselves are not printed */}
        <Button variant="secondary" onClick={onClose} className="mr-2">Close</Button>
        <Button onClick={handlePrint} leftIcon={<PrinterIcon className="w-5 h-5" />}>Print Receipt</Button>
      </div>
    }>
      <div className="printable-area p-4 text-sm" id="receipt-content">
        <div className="text-center mb-6">
          <h2 className="text-xl font-bold">{APP_NAME} Pharmacy</h2>
          <p>123 Health St, Wellness City</p>
          <p>Phone: (555) 123-4567</p>
        </div>

        <div className="mb-4">
          <h3 className="text-lg font-semibold mb-2 border-b pb-1">Bill Details</h3>
          <div className="grid grid-cols-2 gap-x-4 gap-y-1">
            <p><strong>Bill Number:</strong> {bill.billNumber}</p>
            {/* Fix: Replaced parseISO with new Date() */}
            <p><strong>Date:</strong> {format(new Date(bill.date), 'Pp')}</p>
            <p><strong>Customer:</strong> {bill.customerName || 'Walk-in Customer'}</p>
            <p><strong>Billed By:</strong> {bill.billedByUserName}</p>
          </div>
        </div>

        <div className="mb-4">
          <h3 className="text-lg font-semibold mb-2 border-b pb-1">Items</h3>
          <table className="w-full text-left">
            <thead>
              <tr className="border-b">
                <th className="pb-1">Medicine</th>
                <th className="pb-1 text-center">Qty</th>
                <th className="pb-1 text-right">Price</th>
                <th className="pb-1 text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              {bill.items.map((item: BillItem) => (
                <tr key={item.medicineId} className="border-b border-dashed">
                  <td className="py-1">{item.medicineName}</td>
                  <td className="py-1 text-center">{item.quantity}</td>
                  <td className="py-1 text-right">${item.unitPrice.toFixed(2)}</td>
                  <td className="py-1 text-right">${item.totalPrice.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mb-4 grid grid-cols-2">
            <div></div> {/* Empty div for spacing to push summary to right */}
            <div className="space-y-1">
                <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>${bill.totalAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                    <span>Discount:</span>
                    <span>-${bill.discount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                    <span>Tax:</span>
                    <span>${bill.taxAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold text-base border-t pt-1 mt-1">
                    <span>Final Amount:</span>
                    <span>${bill.finalAmount.toFixed(2)}</span>
                </div>
            </div>
        </div>
        
        <div className="text-center mt-6">
          <p>Payment Method: {bill.paymentMethod}</p>
          <p className="mt-2 text-xs">Thank you for your purchase!</p>
        </div>
      </div>
    </Modal>
  );
};

export default BillReceiptModal;