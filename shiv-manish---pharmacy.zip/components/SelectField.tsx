
import React, { SelectHTMLAttributes } from 'react';

interface SelectFieldProps extends SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
  options: { value: string | number; label: string }[];
  containerClassName?: string;
  // Fix: Added placeholder to SelectFieldProps
  placeholder?: string; 
}

// Fix: Destructured placeholder and renamed ...props to ...restSelectProps
const SelectField: React.FC<SelectFieldProps> = ({ 
  label, 
  id, 
  error, 
  options, 
  placeholder, 
  containerClassName = 'mb-4', 
  className = '', 
  ...restSelectProps 
}) => {
  const defaultSelectClasses = "mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md shadow-sm";
  
  return (
    <div className={containerClassName}>
      {label && <label htmlFor={id} className="block text-sm font-medium text-gray-700">{label}</label>}
      <select
        id={id}
        className={`${defaultSelectClasses} ${className} ${error ? 'border-red-500' : ''}`}
        // Fix: Spread ...restSelectProps
        {...restSelectProps}
      >
        {/* Fix: Used destructured placeholder directly */}
        {placeholder && <option value="">{placeholder}</option>}
        {options.map(option => (
          <option key={option.value} value={option.value}>{option.label}</option>
        ))}
      </select>
      {error && <p className="mt-1 text-xs text-red-500">{error}</p>}
    </div>
  );
};

export default SelectField;