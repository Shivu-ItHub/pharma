import React, { useState, useMemo, useCallback } from 'react';
import { Link } from 'react-router-dom'; // Added Link
import { useAppContext } from '../contexts/AppContext';
import { Medicine, TableColumn, UserRole, ReorderStatus, NewBatchDetails, NewBatchInfo, PurchaseRecord } from '../types'; 
import Table from '../components/Table';
import Modal from '../components/Modal';
import Button from '../components/Button';
import InputField from '../components/InputField';
import ConfirmationDialog from '../components/ConfirmationDialog';
import ReorderModal from '../components/ReorderModal';
import ExpiredStockModal from '../components/ExpiredStockModal';
import { PlusCircleIcon, PencilIcon, TrashIcon, ExclamationTriangleIcon, RefreshCwIcon, SendIcon, FilterIcon, ArchiveBoxArrowDownIcon, ReplaceIcon, ExternalLinkIcon } from '../constants'; 
import { differenceInDays, isBefore, format } from 'date-fns';
import { LOW_STOCK_THRESHOLD, EXPIRY_WARNING_DAYS } from '../constants';

const initialMedicineFormState: Omit<Medicine, 'id'> = {
  name: '',
  batchNumber: '',
  manufacturer: '',
  supplier: '',
  category: '',
  expiryDate: '',
  manufacturingDate: '',
  purchasePrice: 0,
  salePrice: 0,
  quantityInStock: 0,
  lowStockThreshold: LOW_STOCK_THRESHOLD,
};

const COMMON_CATEGORIES = ["Analgesic", "Antibiotic", "Antiseptic", "Antihistamine", "NSAID", "Vitamin", "Herbal", "Syrup", "Tablet", "Capsule", "Ointment"];


const MedicinesPage: React.FC = () => {
  const { state, dispatch } = useAppContext();
  const { medicines, currentUser, reorderRequests } = state; 
  
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [editingMedicine, setEditingMedicine] = useState<Medicine | null>(null);
  const [medicineForm, setMedicineForm] = useState<Omit<Medicine, 'id'>>(initialMedicineFormState);
  
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [filterLowStock, setFilterLowStock] = useState(false);
  const [filterExpiringSoon, setFilterExpiringSoon] = useState(false); // Includes already expired

  const [isConfirmDeleteDialogOpen, setIsConfirmDeleteDialogOpen] = useState(false);
  const [medicineToDelete, setMedicineToDelete] = useState<Medicine | null>(null);

  const [isReorderModalOpen, setIsReorderModalOpen] = useState(false);
  const [reorderingMedicine, setReorderingMedicine] = useState<Medicine | null>(null);

  const [isExpiredStockModalOpen, setIsExpiredStockModalOpen] = useState(false); 
  const [handlingExpiredMedicine, setHandlingExpiredMedicine] = useState<Medicine | null>(null); 
  
  const isAdmin = currentUser?.role === UserRole.ADMIN;
  const canManageMedicineDetails = currentUser?.role === UserRole.ADMIN || currentUser?.role === UserRole.PHARMACIST;


  const manufacturersList = useMemo(() => Array.from(new Set(medicines.map(m => m.manufacturer).filter(Boolean))), [medicines]);
  const suppliersList = useMemo(() => Array.from(new Set(medicines.map(m => m.supplier).filter(Boolean))), [medicines]);
  const categoriesList = useMemo(() => Array.from(new Set([...COMMON_CATEGORIES, ...medicines.map(m => m.category).filter(Boolean).map(c => c!)])), [medicines]);


  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const val = type === 'number' ? parseFloat(value) : value;
    setMedicineForm(prev => ({ ...prev, [name]: val }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingMedicine) {
      dispatch({ type: 'UPDATE_MEDICINE', payload: { ...editingMedicine, ...medicineForm } });
    } else {
      const newMedicineId = `MED-${Date.now()}`;
      const newMedicinePayload: Medicine = { 
        id: newMedicineId, 
        ...medicineForm,
        lowStockThreshold: medicineForm.lowStockThreshold || LOW_STOCK_THRESHOLD // Ensure threshold has a value
      };
      dispatch({ type: 'ADD_MEDICINE', payload: newMedicinePayload });

      // Create a purchase record for the initial stock addition
      const initialPurchaseRecord: PurchaseRecord = {
        id: `PR-INIT-${Date.now()}`,
        medicineId: newMedicineId,
        medicineName: newMedicinePayload.name,
        supplier: newMedicinePayload.supplier,
        batchNumber: newMedicinePayload.batchNumber,
        manufacturingDate: newMedicinePayload.manufacturingDate,
        expiryDate: newMedicinePayload.expiryDate,
        quantityPurchased: newMedicinePayload.quantityInStock,
        purchasePricePerUnit: newMedicinePayload.purchasePrice,
        salePricePerUnit: newMedicinePayload.salePrice,
        totalPurchaseCost: newMedicinePayload.purchasePrice * newMedicinePayload.quantityInStock,
        purchaseDate: new Date().toISOString(),
        notes: "Initial stock addition of new medicine.",
      };
      dispatch({ type: 'ADD_PURCHASE_RECORD', payload: initialPurchaseRecord });
    }
    closeFormModal();
  };

  const openFormModal = (medicine?: Medicine) => {
    if (medicine) {
      setEditingMedicine(medicine);
      setMedicineForm({
        ...initialMedicineFormState, 
        ...medicine,
        supplier: medicine.supplier || '',
        category: medicine.category || '',
        lowStockThreshold: medicine.lowStockThreshold || LOW_STOCK_THRESHOLD,
      });
    } else {
      setEditingMedicine(null);
      setMedicineForm({...initialMedicineFormState, lowStockThreshold: LOW_STOCK_THRESHOLD });
    }
    setIsFormModalOpen(true);
  };

  const closeFormModal = () => {
    setIsFormModalOpen(false);
    setEditingMedicine(null);
    setMedicineForm(initialMedicineFormState);
  };

  const handleDeleteClick = (medicine: Medicine) => {
    setMedicineToDelete(medicine);
    setIsConfirmDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (medicineToDelete) {
      dispatch({ type: 'DELETE_MEDICINE', payload: medicineToDelete.id });
    }
    setIsConfirmDeleteDialogOpen(false);
    setMedicineToDelete(null);
  };

  const handleReorderClick = (medicine: Medicine) => {
    setReorderingMedicine(medicine);
    setIsReorderModalOpen(true);
  };

  const handleConfirmReorder = (medicine: Medicine, quantity: number, batchDetails: NewBatchInfo) => {
    if (!currentUser || currentUser.role !== UserRole.ADMIN) { 
      alert("Error: Only Admins can create re-order requests.");
      return;
    }

    const newReorderRequest = {
      id: `RO-${Date.now()}`,
      medicineId: medicine.id,
      medicineName: medicine.name,
      supplier: medicine.supplier,
      quantityOrdered: quantity,
      requestedByUserId: currentUser.id,
      requestedByUserName: currentUser.name,
      requestDate: new Date().toISOString(),
      status: ReorderStatus.PENDING,
      newBatchDetails: batchDetails, 
    };
    dispatch({ type: 'ADD_REORDER_REQUEST', payload: newReorderRequest });
    
    const alertMessage = `Re-order request for ${quantity} of "${medicine.name}" (New Batch: ${batchDetails.batchNumber}) has been created with PENDING status.\n\n` +
                         `(Stock and medicine details will be updated when an Admin marks this re-order as 'Completed'.)`;
    alert(alertMessage);
    setIsReorderModalOpen(false);
    setReorderingMedicine(null);
  };

  // Handlers for Expired Stock Modal
  const openExpiredStockModal = (medicine: Medicine) => {
    setHandlingExpiredMedicine(medicine);
    setIsExpiredStockModalOpen(true);
  };

  const handleDisposeStock = (medicineId: string) => {
    dispatch({ type: 'DISPOSE_EXPIRED_STOCK', payload: { medicineId } });
    console.log(`Disposed stock for medicine ID: ${medicineId}`);
    alert(`Stock for medicine ID ${medicineId} has been set to 0.`);
    setIsExpiredStockModalOpen(false); 
    setHandlingExpiredMedicine(null);
  };

  const handleReplaceBatch = (medicineId: string, newBatchDetails: NewBatchDetails) => {
    const medicine = medicines.find(m => m.id === medicineId);
    if (!medicine) {
        alert("Original medicine not found for replacement.");
        return;
    }

    dispatch({ type: 'REPLACE_EXPIRED_BATCH', payload: { medicineId, details: newBatchDetails } });

    const purchaseRecord: PurchaseRecord = {
      id: `PR-EXP-${Date.now()}`,
      medicineId: medicineId,
      medicineName: medicine.name, 
      supplier: medicine.supplier, 
      batchNumber: newBatchDetails.batchNumber,
      manufacturingDate: newBatchDetails.manufacturingDate,
      expiryDate: newBatchDetails.expiryDate,
      quantityPurchased: newBatchDetails.newQuantityInStock,
      purchasePricePerUnit: newBatchDetails.purchasePrice,
      salePricePerUnit: newBatchDetails.salePrice,
      totalPurchaseCost: newBatchDetails.newQuantityInStock * newBatchDetails.purchasePrice,
      purchaseDate: new Date().toISOString(),
      notes: `Expired stock replacement for original batch ${medicine.batchNumber}.`
    };
    dispatch({ type: 'ADD_PURCHASE_RECORD', payload: purchaseRecord });
    
    alert(`Batch for ${medicine.name} replaced and purchase recorded. New stock: ${newBatchDetails.newQuantityInStock}.`);
    setIsExpiredStockModalOpen(false); 
    setHandlingExpiredMedicine(null);
  };


  const filteredMedicines = useMemo(() => {
    return medicines.filter(med => {
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch = med.name.toLowerCase().includes(searchLower) ||
                            med.batchNumber.toLowerCase().includes(searchLower) ||
                            med.manufacturer.toLowerCase().includes(searchLower) ||
                            (med.supplier || '').toLowerCase().includes(searchLower) ||
                            (med.category || '').toLowerCase().includes(searchLower);
      
      const isLowStock = med.quantityInStock < (med.lowStockThreshold || LOW_STOCK_THRESHOLD);
      const expiryDateObj = new Date(med.expiryDate);
      const today = new Date();
      today.setHours(0,0,0,0);
      expiryDateObj.setHours(0,0,0,0);

      const isActuallyExpired = isBefore(expiryDateObj, today);
      const isExpiringSoon = differenceInDays(expiryDateObj, today) <= EXPIRY_WARNING_DAYS && !isActuallyExpired;
      
      const matchesExpiryFilter = isActuallyExpired || isExpiringSoon;

      if (filterLowStock && filterExpiringSoon) return matchesSearch && isLowStock && matchesExpiryFilter;
      if (filterLowStock) return matchesSearch && isLowStock;
      if (filterExpiringSoon) return matchesSearch && matchesExpiryFilter;
      return matchesSearch;
    });
  }, [medicines, searchTerm, filterLowStock, filterExpiringSoon]);
  
  const activeFilterCount = (filterLowStock ? 1 : 0) + (filterExpiringSoon ? 1 : 0);

  const columns: TableColumn<Medicine>[] = [
    { key: 'name', header: 'Name', render: (item) => {
      const expiryDateObj = new Date(item.expiryDate);
      const today = new Date();
      today.setHours(0,0,0,0);
      expiryDateObj.setHours(0,0,0,0);
      const isActuallyExpired = isBefore(expiryDateObj, today);
      const isExpiringSoon = differenceInDays(expiryDateObj, today) <= EXPIRY_WARNING_DAYS && !isActuallyExpired;

      return (
        <div className="flex items-center">
          {item.name}
          {item.quantityInStock < (item.lowStockThreshold || LOW_STOCK_THRESHOLD) && 
            <span title={`Low Stock: ${item.quantityInStock} remaining (Threshold: ${item.lowStockThreshold || LOW_STOCK_THRESHOLD})`}>
              <ExclamationTriangleIcon className="w-4 h-4 ml-2 text-yellow-500" />
            </span>}
          {isActuallyExpired &&
            <span title={`EXPIRED on: ${format(expiryDateObj, 'P')}`}>
              <ExclamationTriangleIcon className="w-4 h-4 ml-1 text-red-700 font-bold" />
            </span>}
          {isExpiringSoon && !isActuallyExpired &&
            <span title={`Expiring Soon: ${format(expiryDateObj, 'P')}`}>
              <ExclamationTriangleIcon className="w-4 h-4 ml-1 text-orange-500" />
            </span>}
        </div>
      )}
    },
    { key: 'batchNumber', header: 'Batch No.' },
    { key: 'manufacturer', header: 'Manufacturer' },
    { key: 'supplier', header: 'Supplier', render: (item) => item.supplier || 'N/A' },
    { key: 'category', header: 'Category', render: (item) => item.category || 'N/A' },
    { key: 'expiryDate', header: 'Expiry Date', render: (item) => format(new Date(item.expiryDate), 'P') },
    { key: 'quantityInStock', header: 'Stock' },
    { key: 'salePrice', header: 'Sale Price', render: (item) => `$${item.salePrice.toFixed(2)}` },
    { key: 'purchasePrice', header: 'Purchase Price', render: (item) => `$${item.purchasePrice.toFixed(2)}` },
    ...(canManageMedicineDetails ? [{ 
      key: 'actions', 
      header: 'Actions', 
      render: (item: Medicine) => {
        const isActuallyExpired = isBefore(new Date(item.expiryDate), new Date());
        const isLowStock = item.quantityInStock < (item.lowStockThreshold || LOW_STOCK_THRESHOLD);
        const existingPendingRequest = reorderRequests.find(
            req => req.medicineId === item.id && req.status === ReorderStatus.PENDING
        );

        return (
          <div className="flex flex-wrap gap-1.5">
            <Button size="sm" variant="secondary" onClick={(e) => { e.stopPropagation(); openFormModal(item); }} leftIcon={<PencilIcon className="w-4 h-4"/>} title="Edit Medicine Details">Edit</Button>
            <Button size="sm" variant="danger" onClick={(e) => { e.stopPropagation(); handleDeleteClick(item);}} leftIcon={<TrashIcon className="w-4 h-4"/>} title="Delete Medicine">Delete</Button>
            
            {isActuallyExpired && (
              <Button 
                size="sm" 
                variant="warning" 
                onClick={(e) => { e.stopPropagation(); openExpiredStockModal(item);}} 
                leftIcon={<ArchiveBoxArrowDownIcon className="w-4 h-4"/>} 
                title="Handle Expired Stock (Dispose/Replace)"
              >
                Handle Expired
              </Button>
            )}

            {isAdmin && isLowStock && !isActuallyExpired && (
                existingPendingRequest ? (
                    <Link to="/reorders">
                        <Button
                            size="sm"
                            variant="secondary"
                            leftIcon={<ExternalLinkIcon className="w-4 h-4" />}
                            title={`A re-order (ID: ${existingPendingRequest.id}) is already PENDING for this item. Click to view.`}
                        >
                            View Pending Order
                        </Button>
                    </Link>
                ) : (
                   <Button 
                      size="sm" 
                      variant="warning" 
                      onClick={(e) => { e.stopPropagation(); handleReorderClick(item); }} 
                      leftIcon={<RefreshCwIcon className="w-4 h-4"/>}
                      title={`Stock is ${item.quantityInStock}, threshold is ${item.lowStockThreshold || LOW_STOCK_THRESHOLD}. Initiate re-order.`}
                    >
                      Re-order
                    </Button>
                )
            )}
          </div>
        );
      }
    }] : [])
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-6">
        <h1 className="text-3xl font-semibold text-gray-800">Manage Medicines</h1>
        {canManageMedicineDetails && <Button onClick={() => openFormModal()} leftIcon={<PlusCircleIcon className="w-5 h-5"/>} className="w-full sm:w-auto">Add Medicine</Button>}
      </div>

      <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <InputField
              placeholder="Search by name, batch, mfg, supplier, category..."
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              containerClassName="flex-grow mb-0 w-full" 
              className="text-sm sm:text-base"
            />
            <Button
              variant="secondary"
              onClick={() => setShowFilters(!showFilters)}
              leftIcon={<FilterIcon className="w-5 h-5" />}
              className="w-full sm:w-auto flex-shrink-0"
            >
              {showFilters ? 'Hide Filters' : 'Show Filters'}
              {activeFilterCount > 0 && <span className="ml-1.5 bg-primary-500 text-white text-xs font-semibold px-1.5 py-0.5 rounded-full">{activeFilterCount}</span>}
            </Button>
        </div>
        {showFilters && (
            <div className="mt-4 pt-4 border-t border-gray-200">
            <p className="text-sm font-medium text-gray-700 mb-2">Filter by:</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3">
                <label className="flex items-center space-x-2 p-2 rounded-md hover:bg-gray-50 transition-colors cursor-pointer">
                <input type="checkbox" checked={filterLowStock} onChange={(e) => setFilterLowStock(e.target.checked)} className="form-checkbox h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"/>
                <span className="text-sm text-gray-700">Low Stock</span>
                </label>
                <label className="flex items-center space-x-2 p-2 rounded-md hover:bg-gray-50 transition-colors cursor-pointer">
                <input type="checkbox" checked={filterExpiringSoon} onChange={(e) => setFilterExpiringSoon(e.target.checked)} className="form-checkbox h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"/>
                <span className="text-sm text-gray-700">Expiring Soon / Expired</span>
                </label>
            </div>
            </div>
        )}
      </div>
      
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <Table columns={columns} data={filteredMedicines} keyExtractor={(item) => item.id} emptyStateMessage="No medicines match your criteria."/>
      </div>


      {canManageMedicineDetails && (
        <Modal isOpen={isFormModalOpen} onClose={closeFormModal} title={editingMedicine ? 'Edit Medicine' : 'Add New Medicine'}>
          <form onSubmit={handleSubmit} className="space-y-4">
            <InputField label="Name" name="name" value={medicineForm.name} onChange={handleInputChange} required />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <InputField label="Batch Number" name="batchNumber" value={medicineForm.batchNumber} onChange={handleInputChange} required />
              <div>
                <InputField 
                    label="Manufacturer" 
                    name="manufacturer" 
                    value={medicineForm.manufacturer} 
                    onChange={handleInputChange} 
                    list="manufacturers-list" 
                    required 
                />
                <datalist id="manufacturers-list">
                    {manufacturersList.map(m => <option key={m} value={m} />)}
                </datalist>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <InputField 
                    label="Supplier" 
                    name="supplier" 
                    value={medicineForm.supplier || ''} 
                    onChange={handleInputChange} 
                    list="suppliers-list" 
                />
                <datalist id="suppliers-list">
                    {suppliersList.map(s => <option key={s} value={s} />)}
                </datalist>
              </div>
              <div>
                <InputField 
                    label="Category" 
                    name="category" 
                    value={medicineForm.category || ''} 
                    onChange={handleInputChange} 
                    list="categories-list" 
                />
                <datalist id="categories-list">
                    {categoriesList.map(c => <option key={c} value={c} />)}
                </datalist>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <InputField label="Manufacturing Date" name="manufacturingDate" type="date" value={medicineForm.manufacturingDate} onChange={handleInputChange} required />
              <InputField label="Expiry Date" name="expiryDate" type="date" value={medicineForm.expiryDate} onChange={handleInputChange} required />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <InputField label="Purchase Price" name="purchasePrice" type="number" step="0.01" min="0" value={medicineForm.purchasePrice} onChange={handleInputChange} required />
              <InputField label="Sale Price" name="salePrice" type="number" step="0.01" min="0" value={medicineForm.salePrice} onChange={handleInputChange} required />
              <InputField label="Quantity in Stock" name="quantityInStock" type="number" min="0" value={medicineForm.quantityInStock} onChange={handleInputChange} required />
            </div>
             <InputField label="Low Stock Threshold" name="lowStockThreshold" type="number" min="0" value={medicineForm.lowStockThreshold || LOW_STOCK_THRESHOLD} onChange={handleInputChange} />
            <div className="flex justify-end space-x-2 pt-4">
              <Button type="button" variant="secondary" onClick={closeFormModal}>Cancel</Button>
              <Button type="submit">{editingMedicine ? 'Save Changes' : 'Add Medicine'}</Button>
            </div>
          </form>
        </Modal>
      )}
      
      <ConfirmationDialog
        isOpen={isConfirmDeleteDialogOpen}
        onClose={() => setIsConfirmDeleteDialogOpen(false)}
        onConfirm={confirmDelete}
        title="Confirm Deletion"
        message={`Are you sure you want to delete ${medicineToDelete?.name}? This action cannot be undone.`}
      />
      
      {isAdmin && ( 
        <ReorderModal 
          isOpen={isReorderModalOpen}
          onClose={() => { setIsReorderModalOpen(false); setReorderingMedicine(null); }}
          medicine={reorderingMedicine}
          onConfirmReorder={handleConfirmReorder}
        />
      )}


      {canManageMedicineDetails && handlingExpiredMedicine && (
        <ExpiredStockModal
          isOpen={isExpiredStockModalOpen}
          onClose={() => {
            setIsExpiredStockModalOpen(false);
            setHandlingExpiredMedicine(null);
          }}
          medicine={handlingExpiredMedicine}
          onDisposeStock={handleDisposeStock}
          onReplaceBatch={handleReplaceBatch}
        />
      )}
    </div>
  );
};

export default MedicinesPage;