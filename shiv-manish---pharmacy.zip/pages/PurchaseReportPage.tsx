
import React, { useState, useMemo } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { PurchaseRecord, Medicine, TableColumn } from '../types';
import Table from '../components/Table';
import Button from '../components/Button';
import InputField from '../components/InputField';
import SelectField from '../components/SelectField';
import { ShoppingBagIcon, DownloadIcon } from '../constants';
// Fix: Imported 'isBefore' and 'isAfter' from 'date-fns'
import { format, parseISO, isValid, startOfMonth, endOfMonth, eachMonthOfInterval, getMonth, getYear, isBefore, isAfter } from 'date-fns';
import { exportToExcel, SheetData } from '../utils/exportToExcel';

const PurchaseReportPage: React.FC = () => {
  const { state } = useAppContext();
  const { purchaseRecords, medicines } = state;

  const today = new Date();
  const [filters, setFilters] = useState({
    startDate: format(startOfMonth(today), 'yyyy-MM-dd'),
    endDate: format(today, 'yyyy-MM-dd'),
    supplier: '',
    medicineId: '',
  });

  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const supplierOptions = useMemo(() => {
    const uniqueSuppliers = Array.from(new Set(purchaseRecords.map(pr => pr.supplier).filter(Boolean as any as (value: string | undefined) => value is string)));
    return [{ value: '', label: 'All Suppliers' }, ...uniqueSuppliers.map(s => ({ value: s, label: s }))];
  }, [purchaseRecords]);

  const medicineOptions = useMemo(() => [{ value: '', label: 'All Medicines' }, ...medicines.map(m => ({ value: m.id, label: m.name }))], [medicines]);

  const filteredPurchaseRecords = useMemo(() => {
    let tempRecords = [...purchaseRecords];

    if (filters.startDate && isValid(parseISO(filters.startDate))) {
      const startDate = parseISO(filters.startDate);
      tempRecords = tempRecords.filter(pr => !isBefore(parseISO(pr.purchaseDate), startDate));
    }
    if (filters.endDate && isValid(parseISO(filters.endDate))) {
      const endDate = parseISO(filters.endDate);
      endDate.setHours(23,59,59,999); 
      tempRecords = tempRecords.filter(pr => !isAfter(parseISO(pr.purchaseDate), endDate));
    }
    if (filters.supplier) {
      tempRecords = tempRecords.filter(pr => pr.supplier === filters.supplier);
    }
    if (filters.medicineId) {
      tempRecords = tempRecords.filter(pr => pr.medicineId === filters.medicineId);
    }
    return tempRecords.sort((a,b) => new Date(b.purchaseDate).getTime() - new Date(a.purchaseDate).getTime());
  }, [purchaseRecords, filters]);

  const summaryStats = useMemo(() => {
    const totalPurchaseEntries = filteredPurchaseRecords.length;
    const totalQuantityPurchased = filteredPurchaseRecords.reduce((sum, pr) => sum + pr.quantityPurchased, 0);
    const totalPurchaseCost = filteredPurchaseRecords.reduce((sum, pr) => sum + pr.totalPurchaseCost, 0);
    return { totalPurchaseEntries, totalQuantityPurchased, totalPurchaseCost };
  }, [filteredPurchaseRecords]);

  const purchaseColumns: TableColumn<PurchaseRecord>[] = [
    { key: 'purchaseDate', header: 'Date', render: (item) => format(parseISO(item.purchaseDate), 'Pp') },
    { key: 'medicineName', header: 'Medicine' },
    { key: 'batchNumber', header: 'Batch No.' },
    { key: 'supplier', header: 'Supplier', render: (item) => item.supplier || 'N/A' },
    { key: 'quantityPurchased', header: 'Qty Purchased' },
    { key: 'purchasePricePerUnit', header: 'Unit Cost', render: (item) => `$${item.purchasePricePerUnit.toFixed(2)}` },
    { key: 'totalPurchaseCost', header: 'Total Cost', render: (item) => `$${item.totalPurchaseCost.toFixed(2)}` },
    { key: 'notes', header: 'Notes' },
  ];
  
  const handleDownloadReport = () => {
    const reportDate = format(new Date(), 'yyyy-MM-dd');
    const fileName = `PurchaseReport_${filters.startDate}_to_${filters.endDate || reportDate}`;

    const purchaseDataSheet = filteredPurchaseRecords.map(pr => ({
      'Purchase ID': pr.id,
      'Date': format(parseISO(pr.purchaseDate), 'yyyy-MM-dd HH:mm'),
      'Medicine ID': pr.medicineId,
      'Medicine Name': pr.medicineName,
      'Batch Number': pr.batchNumber,
      'Supplier': pr.supplier || 'N/A',
      'Quantity Purchased': pr.quantityPurchased,
      'Purchase Price Per Unit': pr.purchasePricePerUnit,
      'Total Purchase Cost': pr.totalPurchaseCost,
      'Mfg Date': pr.manufacturingDate ? format(parseISO(pr.manufacturingDate), 'yyyy-MM-dd') : 'N/A',
      'Exp Date': pr.expiryDate ? format(parseISO(pr.expiryDate), 'yyyy-MM-dd') : 'N/A',
      'Related Reorder ID': pr.relatedReorderId || 'N/A',
      'Notes': pr.notes || '',
    }));

    const summarySheetData = [
      { Metric: 'Selected Period', Value: `${filters.startDate} to ${filters.endDate}`},
      { Metric: 'Total Purchase Entries', Value: summaryStats.totalPurchaseEntries },
      { Metric: 'Total Quantity Purchased (Units)', Value: summaryStats.totalQuantityPurchased },
      { Metric: 'Total Purchase Cost', Value: summaryStats.totalPurchaseCost.toFixed(2) },
    ];

    const monthlyPurchases: { [month: string]: { entries: number, cost: number, quantity: number } } = {};
    filteredPurchaseRecords.forEach(pr => {
      const monthYear = format(parseISO(pr.purchaseDate), 'yyyy-MM');
      if (!monthlyPurchases[monthYear]) monthlyPurchases[monthYear] = { entries: 0, cost: 0, quantity: 0 };
      monthlyPurchases[monthYear].entries++;
      monthlyPurchases[monthYear].cost += pr.totalPurchaseCost;
      monthlyPurchases[monthYear].quantity += pr.quantityPurchased;
    });
    const monthlyPurchasesSheetData = Object.entries(monthlyPurchases).map(([month, data]) => ({
      Month: month,
      'Total Entries': data.entries,
      'Total Cost': data.cost.toFixed(2),
      'Total Quantity': data.quantity,
    })).sort((a,b) => a.Month.localeCompare(b.Month));

    const productPurchases: { [medId: string]: { name: string; quantity: number; cost: number } } = {};
    filteredPurchaseRecords.forEach(pr => {
        if (!productPurchases[pr.medicineId]) {
          productPurchases[pr.medicineId] = { name: pr.medicineName, quantity: 0, cost: 0 };
        }
        productPurchases[pr.medicineId].quantity += pr.quantityPurchased;
        productPurchases[pr.medicineId].cost += pr.totalPurchaseCost;
    });
    const topPurchasedQtySheetData = Object.values(productPurchases)
      .sort((a, b) => b.quantity - a.quantity)
      .slice(0, 20)
      .map(p => ({ 'Medicine Name': p.name, 'Quantity Purchased': p.quantity, 'Total Cost': p.cost.toFixed(2) }));

    const purchasesBySupplier: { [supplier: string]: { entries: number; cost: number } } = {};
    filteredPurchaseRecords.forEach(pr => {
      const sup = pr.supplier || 'Unknown Supplier';
      if (!purchasesBySupplier[sup]) purchasesBySupplier[sup] = { entries: 0, cost: 0 };
      purchasesBySupplier[sup].entries++;
      purchasesBySupplier[sup].cost += pr.totalPurchaseCost;
    });
    const purchasesBySupplierSheetData = Object.entries(purchasesBySupplier)
      .sort((a,b) => b[1].cost - a[1].cost)
      .map(([supplier, data]) => ({ 'Supplier': supplier, 'Number of Purchases': data.entries, 'Total Cost': data.cost.toFixed(2) }));


    const sheets: SheetData[] = [
      { sheetName: 'Purchase Data', data: purchaseDataSheet, columnWidths: [{wch:15},{wch:18},{wch:15},{wch:25},{wch:15},{wch:20},{wch:15},{wch:18},{wch:18},{wch:12},{wch:12},{wch:20},{wch:20}] },
      { sheetName: 'Overall Summary', data: summarySheetData, columnWidths: [{wch:30},{wch:15}] },
      { sheetName: 'Monthly Summary', data: monthlyPurchasesSheetData, columnWidths: [{wch:15},{wch:15},{wch:15},{wch:15}] },
      { sheetName: 'Top Purchased (Qty)', data: topPurchasedQtySheetData, columnWidths: [{wch:30},{wch:20},{wch:15}] },
      { sheetName: 'Purchases By Supplier', data: purchasesBySupplierSheetData, columnWidths: [{wch:30},{wch:20},{wch:15}] },
    ];
    
    exportToExcel(fileName, sheets);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <h1 className="text-3xl font-semibold text-gray-800 flex items-center">
          <ShoppingBagIcon className="w-8 h-8 mr-2 text-primary-700" />
          Purchase Report
        </h1>
        <Button onClick={handleDownloadReport} leftIcon={<DownloadIcon className="w-5 h-5"/>}>Download Excel Report</Button>
      </div>

      <div className="p-4 bg-white shadow rounded-lg">
        <h2 className="text-xl font-semibold text-gray-700 mb-4">Filters</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <InputField label="Start Date" type="date" name="startDate" value={filters.startDate} onChange={handleFilterChange} />
          <InputField label="End Date" type="date" name="endDate" value={filters.endDate} onChange={handleFilterChange} />
          <SelectField label="Supplier" name="supplier" value={filters.supplier} options={supplierOptions} onChange={handleFilterChange} />
          <SelectField label="Medicine" name="medicineId" value={filters.medicineId} options={medicineOptions} onChange={handleFilterChange} />
        </div>
      </div>

      <div className="p-4 bg-white shadow rounded-lg">
        <h2 className="text-xl font-semibold text-gray-700 mb-4">Summary Statistics (for selected period)</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          <div><strong>Total Purchase Entries:</strong> {summaryStats.totalPurchaseEntries}</div>
          <div><strong>Total Quantity Purchased (Units):</strong> {summaryStats.totalQuantityPurchased}</div>
          <div className="font-bold"><strong>Total Purchase Cost:</strong> ${summaryStats.totalPurchaseCost.toFixed(2)}</div>
        </div>
      </div>
      
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <Table columns={purchaseColumns} data={filteredPurchaseRecords} keyExtractor={(item) => item.id} emptyStateMessage="No purchase records found for the selected filters."/>
      </div>
    </div>
  );
};

export default PurchaseReportPage;