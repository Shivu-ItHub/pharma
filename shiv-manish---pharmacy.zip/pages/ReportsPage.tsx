
import React, { useState, useMemo, useEffect } from 'react';
import { useAppContext } from '../contexts/AppContext';
// Fix: Imported UserRole
import { Medicine, Bill, TableColumn, ReportType, ArchivedReport, UserRole } from '../types';
import Table from '../components/Table';
import { ExclamationTriangleIcon, DownloadIcon, ArchiveBoxIcon } from '../constants'; 
import { differenceInDays, isBefore, format, getYear, getMonth, isValid } from 'date-fns';
import { LOW_STOCK_THRESHOLD, EXPIRY_WARNING_DAYS } from '../constants';
import InputField from '../components/InputField';
import Button from '../components/Button';
import SelectField from '../components/SelectField';


declare var XLSX: any; // Ensure XLSX is available globally (from CDN or Electron preload)

// Extend window interface for Electron API
declare global {
    interface Window {
      electronAPI: {
        getDocumentsPath: () => Promise<string>;
        ensureDirectory: (dirPath: string) => Promise<{success: boolean, path?: string, error?: string}>;
        saveExcelB64: (args: { filePath: string; data: string }) => Promise<{success: boolean, path?: string, error?: string}>;
        // ... other electronAPI methods if any
      }
    }
}


const ReportsPage: React.FC = () => {
  const { state, dispatch } = useAppContext();
  const { medicines, bills, currentUser } = state;
  const [activeReport, setActiveReport] = useState<ReportType>('sales');
  
  const currentYear = getYear(new Date());
  const currentMonth = getMonth(new Date()) + 1; // date-fns month is 0-indexed

  const [reportPeriodYear, setReportPeriodYear] = useState<number>(currentYear);
  const [reportPeriodMonth, setReportPeriodMonth] = useState<number>(currentMonth);
  
  // Sales report still uses its own daily filter for *data display*
  const [salesDateFilter, setSalesDateFilter] = useState<string>(format(new Date(), 'yyyy-MM-dd'));

  const yearOptions = useMemo(() => {
    const years = [];
    for (let i = 0; i < 5; i++) { // Current year and 4 previous years
      years.push({ value: currentYear - i, label: (currentYear - i).toString() });
    }
    return years;
  }, [currentYear]);

  const monthOptions = useMemo(() => 
    Array.from({ length: 12 }, (_, i) => ({ value: i + 1, label: format(new Date(currentYear, i), 'MMMM') }))
  , [currentYear]);


  const lowStockMedicines = useMemo(() => 
    medicines.filter(med => med.quantityInStock < (med.lowStockThreshold || LOW_STOCK_THRESHOLD)),
    [medicines]
  );

  const expiryMedicines = useMemo(() => 
    medicines.filter(med => {
      const expiryDate = new Date(med.expiryDate);
      const today = new Date();
      return isBefore(expiryDate, today) || differenceInDays(expiryDate, today) <= EXPIRY_WARNING_DAYS;
    }).sort((a,b) => differenceInDays(new Date(a.expiryDate), new Date(b.expiryDate))),
    [medicines]
  );

  const filteredSales = useMemo(() => {
    if (!salesDateFilter) return bills;
    const targetDate = new Date(salesDateFilter);
    if (!isValid(targetDate)) return [];
    return bills.filter(bill => {
        const billDate = new Date(bill.date);
        return isValid(billDate) && format(billDate, 'yyyy-MM-dd') === format(targetDate, 'yyyy-MM-dd');
    });
  }, [bills, salesDateFilter]);


  const handleArchiveReport = async () => {
    if (!currentUser || currentUser.role !== UserRole.ADMIN) {
        alert("Only Admins can archive reports.");
        return;
    }
    if (!window.electronAPI) {
        alert("File system operations are not available. Cannot archive report.");
        return;
    }

    let reportDataArray: any[] = [];
    let fileNameSuffix = '';
    let reportDateForFileName: Date;

    // Determine the date to use for filename and folder structure
    // For sales, use salesDateFilter. For others, use selected reportPeriodYear/Month (first day of that month).
    if (activeReport === 'sales') {
        if (!salesDateFilter || !isValid(new Date(salesDateFilter))) {
            alert("Please select a valid date for the sales report.");
            return;
        }
        reportDateForFileName = new Date(salesDateFilter);
    } else {
        reportDateForFileName = new Date(reportPeriodYear, reportPeriodMonth - 1, 1);
    }
    
    const year = getYear(reportDateForFileName);
    const month = getMonth(reportDateForFileName) + 1; // 1-12
    const day = activeReport === 'sales' ? format(reportDateForFileName, 'dd') : null;


    switch (activeReport) {
      case 'sales':
        reportDataArray = filteredSales.map(b => ({
          "Bill Number": b.billNumber,
          "Date": format(new Date(b.date), 'Pp'),
          "Customer": b.customerName || 'Walk-in',
          "Items Count": b.items.length,
          "Discount": b.discount.toFixed(2),
          "Tax Amount": b.taxAmount.toFixed(2),
          "Final Amount": b.finalAmount.toFixed(2),
          "Payment Method": b.paymentMethod,
          "Billed By": b.billedByUserName,
        }));
        fileNameSuffix = `Sales_Report_${format(reportDateForFileName, 'yyyy-MM-dd')}`;
        break;
      case 'inventory':
        reportDataArray = medicines.map(m => ({
          "ID": m.id, "Name": m.name, "Batch Number": m.batchNumber, "Manufacturer": m.manufacturer,
          "Supplier": m.supplier || 'N/A', "Category": m.category || 'N/A',
          "Expiry Date": format(new Date(m.expiryDate), 'P'), "Manufacturing Date": format(new Date(m.manufacturingDate), 'P'),
          "Purchase Price": m.purchasePrice.toFixed(2), "Sale Price": m.salePrice.toFixed(2),
          "Quantity In Stock": m.quantityInStock, "Low Stock Threshold": m.lowStockThreshold || LOW_STOCK_THRESHOLD,
        }));
        fileNameSuffix = `Inventory_Report_${year}-${String(month).padStart(2, '0')}`;
        break;
      case 'expiry':
        reportDataArray = expiryMedicines.map(m => ({
          "Name": m.name, "Batch Number": m.batchNumber, "Supplier": m.supplier || 'N/A',
          "Expiry Date": format(new Date(m.expiryDate), 'P'),
          "Days to Expire/Status": (() => {
            const days = differenceInDays(new Date(m.expiryDate), new Date());
            if (isBefore(new Date(m.expiryDate), new Date())) return "Expired";
            return `${days} days`;
          })(),
          "Quantity In Stock": m.quantityInStock, "Purchase Price": m.purchasePrice.toFixed(2),
        }));
        fileNameSuffix = `Expiry_Report_${year}-${String(month).padStart(2, '0')}`;
        break;
      case 'lowStock':
        reportDataArray = lowStockMedicines.map(m => ({
          "Name": m.name, "Batch Number": m.batchNumber, "Supplier": m.supplier || 'N/A',
          "Quantity In Stock": m.quantityInStock, "Low Stock Threshold": m.lowStockThreshold || LOW_STOCK_THRESHOLD,
          "Last Purchase Price": m.purchasePrice.toFixed(2),
        }));
        fileNameSuffix = `LowStock_Report_${year}-${String(month).padStart(2, '0')}`;
        break;
      default:
        alert("Unknown report type.");
        return;
    }

    if (reportDataArray.length === 0) {
      alert("No data to archive for the current selection.");
      return;
    }

    try {
      const worksheet = XLSX.utils.json_to_sheet(reportDataArray);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "ReportData");
      const excelBase64 = XLSX.write(workbook, { bookType: 'xlsx', type: 'base64' });

      const documentsPath = await window.electronAPI.getDocumentsPath();
      const reportBaseDir = `${documentsPath}/ShivManish_Pharmacy_Reports`;
      const targetDirectory = `${reportBaseDir}/${year}/${String(month).padStart(2, '0')}`;
      
      await window.electronAPI.ensureDirectory(targetDirectory);

      const fileName = `${fileNameSuffix}.xlsx`;
      const fullPath = `${targetDirectory}/${fileName}`;

      const saveResult = await window.electronAPI.saveExcelB64({ filePath: fullPath, data: excelBase64 });

      if (saveResult.success) {
        const archiveEntry: ArchivedReport = {
          id: `AR-${Date.now()}`,
          year: year,
          month: month,
          reportType: activeReport,
          fileName: fileName,
          fullPath: fullPath,
          generationDate: new Date().toISOString(),
        };
        dispatch({ type: 'ADD_ARCHIVED_REPORT', payload: archiveEntry });
        alert(`Report archived successfully: ${fullPath}`);
      } else {
        throw new Error(saveResult.error || "Failed to save report file via Electron API.");
      }
    } catch (error) {
      console.error("Error archiving report:", error);
      alert(`Failed to archive report. ${error.message}`);
    }
  };


  const salesColumns: TableColumn<Bill>[] = [
    { key: 'billNumber', header: 'Bill No.' },
    { key: 'date', header: 'Date', render: (item) => format(new Date(item.date), 'Pp') },
    { key: 'customerName', header: 'Customer', render: (item) => item.customerName || 'Walk-in' },
    { key: 'items', header: 'Items', render: (item) => item.items.length },
    { key: 'finalAmount', header: 'Amount', render: (item) => `$${item.finalAmount.toFixed(2)}` },
    { key: 'billedByUserName', header: 'Billed By' },
  ];

  const inventoryColumns: TableColumn<Medicine>[] = [
    { key: 'name', header: 'Name', render: (item) => (
      <div className="flex items-center">
        {item.name}
        {item.quantityInStock < (item.lowStockThreshold || LOW_STOCK_THRESHOLD) && 
          <span title="Low Stock"><ExclamationTriangleIcon className="w-4 h-4 ml-2 text-yellow-500" /></span>}
        {(isBefore(new Date(item.expiryDate), new Date()) || differenceInDays(new Date(item.expiryDate), new Date()) <= EXPIRY_WARNING_DAYS) &&
          <span title="Expiring Soon/Expired"><ExclamationTriangleIcon className="w-4 h-4 ml-1 text-red-500" /></span>}
      </div>
    )},
    { key: 'batchNumber', header: 'Batch No.' },
    { key: 'manufacturer', header: 'Manufacturer' },
    { key: 'quantityInStock', header: 'Stock Qty' },
    { key: 'salePrice', header: 'Sale Price', render: (item) => `$${item.salePrice.toFixed(2)}` },
    { key: 'expiryDate', header: 'Expiry', render: (item) => format(new Date(item.expiryDate), 'P') },
  ];

  const expiryReportColumns: TableColumn<Medicine>[] = [
    { key: 'name', header: 'Name' },
    { key: 'batchNumber', header: 'Batch No.' },
    { key: 'expiryDate', header: 'Expiry Date', render: (item) => format(new Date(item.expiryDate), 'P') },
    { key: 'daysToExpiry', header: 'Days to Expire/Status', render: (item) => {
        const days = differenceInDays(new Date(item.expiryDate), new Date());
        if (isBefore(new Date(item.expiryDate), new Date())) return <span className="text-red-600 font-semibold">Expired</span>;
        return `${days} days`;
      } 
    },
    { key: 'quantityInStock', header: 'Stock Qty' },
  ];
  
  const lowStockReportColumns: TableColumn<Medicine>[] = [
    { key: 'name', header: 'Name' },
    { key: 'batchNumber', header: 'Batch No.' },
    { key: 'quantityInStock', header: 'Stock Qty' },
    { key: 'lowStockThreshold', header: 'Threshold', render: (item) => item.lowStockThreshold || LOW_STOCK_THRESHOLD },
  ];

  const renderReportContent = () => {
    switch (activeReport) {
      case 'sales':
        return (
          <>
            <div className="mb-4 max-w-xs">
              <InputField 
                label="Filter Sales by Date"
                type="date"
                value={salesDateFilter}
                onChange={(e) => setSalesDateFilter(e.target.value)}
              />
            </div>
            <Table columns={salesColumns} data={filteredSales} keyExtractor={(item) => item.id} emptyStateMessage="No sales found for this date." />
          </>
        );
      case 'inventory':
        return <Table columns={inventoryColumns} data={medicines} keyExtractor={(item) => item.id} emptyStateMessage="No medicines in inventory." />;
      case 'expiry':
        return <Table columns={expiryReportColumns} data={expiryMedicines} keyExtractor={(item) => item.id} emptyStateMessage="No medicines expiring soon or expired." />;
      case 'lowStock':
        return <Table columns={lowStockReportColumns} data={lowStockMedicines} keyExtractor={(item) => item.id} emptyStateMessage="No medicines are currently low on stock." />;
      default:
        return null;
    }
  };
  
  const reportButtons: {label: string, type: ReportType}[] = [
    {label: 'Sales Report', type: 'sales'},
    {label: 'Inventory Stock Report', type: 'inventory'},
    {label: 'Expiry Report', type: 'expiry'},
    {label: 'Low Stock Report', type: 'lowStock'},
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <h1 className="text-3xl font-semibold text-gray-800">Reports</h1>
        {currentUser?.role === UserRole.ADMIN && (
            <Button 
                onClick={handleArchiveReport}
                leftIcon={<ArchiveBoxIcon className="w-5 h-5" />} // Using ArchiveBoxIcon
                variant="success"
            >
                Archive Current View as Report
            </Button>
        )}
      </div>

      {currentUser?.role === UserRole.ADMIN && (
        <div className="p-4 bg-gray-50 rounded-md shadow">
            <h3 className="text-sm font-medium text-gray-700 mb-2">Report Archival Period:</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <SelectField
                    label="Year"
                    options={yearOptions}
                    value={reportPeriodYear}
                    onChange={(e) => setReportPeriodYear(parseInt(e.target.value))}
                    containerClassName="mb-0"
                />
                <SelectField
                    label="Month"
                    options={monthOptions}
                    value={reportPeriodMonth}
                    onChange={(e) => setReportPeriodMonth(parseInt(e.target.value))}
                    containerClassName="mb-0"
                />
            </div>
            <p className="text-xs text-gray-500 mt-2">
                Note: For Sales Report, the "Filter Sales by Date" above dictates the data and filename. 
                For other reports, the Year/Month selected here will be used for filename and archival folder.
            </p>
        </div>
      )}
      
      <div className="flex flex-wrap gap-2 border-b pb-2 mb-4">
        {reportButtons.map(btn => (
             <button
                key={btn.type}
                onClick={() => setActiveReport(btn.type)}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors
                    ${activeReport === btn.type 
                        ? 'bg-primary-600 text-white shadow' 
                        : 'bg-white text-gray-700 hover:bg-gray-100 border'
                    }`}
                >
                {btn.label}
            </button>
        ))}
      </div>

      <div className="bg-white p-6 rounded-lg shadow-lg">
        {renderReportContent()}
      </div>
    </div>
  );
};

export default ReportsPage;
