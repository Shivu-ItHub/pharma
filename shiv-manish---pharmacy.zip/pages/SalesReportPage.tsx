
import React, { useState, useMemo } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { Bill, Customer, Medicine, User, TableColumn } from '../types';
import Table from '../components/Table';
import Button from '../components/Button';
import InputField from '../components/InputField';
import SelectField from '../components/SelectField';
import { ChartBarIcon, DownloadIcon } from '../constants';
// Fix: Imported 'isBefore' and 'isAfter' from 'date-fns'
import { format, parseISO, isValid, startOfMonth, endOfMonth, eachMonthOfInterval, getMonth, getYear, isBefore, isAfter } from 'date-fns';
import { exportToExcel, SheetData } from '../utils/exportToExcel';

const SalesReportPage: React.FC = () => {
  const { state } = useAppContext();
  const { bills, customers, medicines, users } = state;

  const today = new Date();
  const [filters, setFilters] = useState({
    startDate: format(startOfMonth(today), 'yyyy-MM-dd'),
    endDate: format(today, 'yyyy-MM-dd'),
    customerId: '',
    medicineId: '',
    billedByUserId: '',
  });

  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const filteredBills = useMemo(() => {
    let tempBills = [...bills];

    if (filters.startDate && isValid(parseISO(filters.startDate))) {
      const startDate = parseISO(filters.startDate);
      tempBills = tempBills.filter(bill => !isBefore(parseISO(bill.date), startDate));
    }
    if (filters.endDate && isValid(parseISO(filters.endDate))) {
      const endDate = parseISO(filters.endDate);
      endDate.setHours(23,59,59,999); // Ensure end date includes the whole day
      tempBills = tempBills.filter(bill => !isAfter(parseISO(bill.date), endDate));
    }
    if (filters.customerId) {
      tempBills = tempBills.filter(bill => bill.customerId === filters.customerId);
    }
    if (filters.billedByUserId) {
      tempBills = tempBills.filter(bill => bill.billedByUserId === filters.billedByUserId);
    }
    if (filters.medicineId) {
      tempBills = tempBills.filter(bill => bill.items.some(item => item.medicineId === filters.medicineId));
    }
    return tempBills.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [bills, filters]);

  const summaryStats = useMemo(() => {
    const totalBills = filteredBills.length;
    const totalItemsSold = filteredBills.reduce((sum, bill) => sum + bill.items.reduce((itemSum, item) => itemSum + item.quantity, 0), 0);
    const totalSalesAmount = filteredBills.reduce((sum, bill) => sum + bill.totalAmount, 0);
    const totalDiscountGiven = filteredBills.reduce((sum, bill) => sum + bill.discount, 0);
    const totalTaxCollected = filteredBills.reduce((sum, bill) => sum + bill.taxAmount, 0);
    const finalRevenue = filteredBills.reduce((sum, bill) => sum + bill.finalAmount, 0);

    return { totalBills, totalItemsSold, totalSalesAmount, totalDiscountGiven, totalTaxCollected, finalRevenue };
  }, [filteredBills]);

  const customerOptions = useMemo(() => [{ value: '', label: 'All Customers' }, ...customers.map(c => ({ value: c.id, label: c.name }))], [customers]);
  const medicineOptions = useMemo(() => [{ value: '', label: 'All Medicines' }, ...medicines.map(m => ({ value: m.id, label: m.name }))], [medicines]);
  const userOptions = useMemo(() => [{ value: '', label: 'All Users' }, ...users.map(u => ({ value: u.id, label: u.name }))], [users]);

  const salesColumns: TableColumn<Bill>[] = [
    { key: 'billNumber', header: 'Bill No.' },
    { key: 'date', header: 'Date', render: (item) => format(parseISO(item.date), 'Pp') },
    { key: 'customerName', header: 'Customer', render: (item) => item.customerName || 'Walk-in' },
    { key: 'items', header: 'Items Summary', render: (item) => `${item.items.length} types, ${item.items.reduce((acc, curr) => acc + curr.quantity, 0)} units`},
    { key: 'totalAmount', header: 'Subtotal', render: (item) => `$${item.totalAmount.toFixed(2)}` },
    { key: 'discount', header: 'Discount', render: (item) => `$${item.discount.toFixed(2)}` },
    { key: 'taxAmount', header: 'Tax', render: (item) => `$${item.taxAmount.toFixed(2)}` },
    { key: 'finalAmount', header: 'Final Amount', render: (item) => `$${item.finalAmount.toFixed(2)}` },
    { key: 'paymentMethod', header: 'Payment Method' },
    { key: 'billedByUserName', header: 'Billed By' },
  ];

  const handleDownloadReport = () => {
    const reportDate = format(new Date(), 'yyyy-MM-dd');
    const fileName = `SalesReport_${filters.startDate}_to_${filters.endDate || reportDate}`;

    // Sheet 1: Filtered Sales Data
    const salesDataSheet = filteredBills.map(b => ({
      'Bill Number': b.billNumber,
      'Date': format(parseISO(b.date), 'yyyy-MM-dd HH:mm'),
      'Customer ID': b.customerId,
      'Customer Name': b.customerName || 'Walk-in',
      'Subtotal': b.totalAmount,
      'Discount': b.discount,
      'Tax Amount': b.taxAmount,
      'Final Amount': b.finalAmount,
      'Payment Method': b.paymentMethod,
      'Billed By User ID': b.billedByUserId,
      'Billed By User Name': b.billedByUserName,
      'Items Count': b.items.length,
      'Total Quantity Sold': b.items.reduce((acc, curr) => acc + curr.quantity, 0)
    }));
    
    // Sheet 2: Sales Summary (on-page stats)
    const summarySheetData = [
      { Metric: 'Selected Period', Value: `${filters.startDate} to ${filters.endDate}`},
      { Metric: 'Total Bills', Value: summaryStats.totalBills },
      { Metric: 'Total Items Sold (Units)', Value: summaryStats.totalItemsSold },
      { Metric: 'Total Sales (Subtotal)', Value: summaryStats.totalSalesAmount.toFixed(2) },
      { Metric: 'Total Discount Given', Value: summaryStats.totalDiscountGiven.toFixed(2) },
      { Metric: 'Total Tax Collected', Value: summaryStats.totalTaxCollected.toFixed(2) },
      { Metric: 'Final Revenue', Value: summaryStats.finalRevenue.toFixed(2) },
    ];

    // Sheet 3: Monthly Sales Summary
    const monthlySales: { [month: string]: { bills: number, revenue: number, items: number } } = {};
    filteredBills.forEach(bill => {
      const monthYear = format(parseISO(bill.date), 'yyyy-MM');
      if (!monthlySales[monthYear]) monthlySales[monthYear] = { bills: 0, revenue: 0, items: 0 };
      monthlySales[monthYear].bills++;
      monthlySales[monthYear].revenue += bill.finalAmount;
      monthlySales[monthYear].items += bill.items.reduce((s, i) => s + i.quantity, 0);
    });
    const monthlySalesSheetData = Object.entries(monthlySales).map(([month, data]) => ({
      Month: month,
      'Total Bills': data.bills,
      'Total Revenue': data.revenue.toFixed(2),
      'Total Items Sold': data.items,
    })).sort((a,b) => a.Month.localeCompare(b.Month));

    // Sheet 4: Top Selling Products
    const productSales: { [medId: string]: { name: string; quantity: number; revenue: number } } = {};
    filteredBills.forEach(bill => {
      bill.items.forEach(item => {
        if (!productSales[item.medicineId]) {
          const med = medicines.find(m => m.id === item.medicineId);
          productSales[item.medicineId] = { name: med?.name || item.medicineName, quantity: 0, revenue: 0 };
        }
        productSales[item.medicineId].quantity += item.quantity;
        productSales[item.medicineId].revenue += item.totalPrice;
      });
    });
    const topSellingQtySheetData = Object.values(productSales)
      .sort((a, b) => b.quantity - a.quantity)
      .slice(0, 20) // Top 20
      .map(p => ({ 'Medicine Name': p.name, 'Quantity Sold': p.quantity, 'Total Revenue': p.revenue.toFixed(2) }));
    
    const topSellingRevSheetData = Object.values(productSales)
      .sort((a,b) => b.revenue - a.revenue)
      .slice(0,20) // Top 20
      .map(p => ({ 'Medicine Name': p.name, 'Total Revenue': p.revenue.toFixed(2), 'Quantity Sold': p.quantity }));

    // Sheet 5: Sales by Customer
    const customerSales: { [custId: string]: { name: string; bills: number; revenue: number } } = {};
    filteredBills.forEach(bill => {
      const custId = bill.customerId || 'walk-in';
      if (!customerSales[custId]) {
        const cust = customers.find(c => c.id === bill.customerId);
        customerSales[custId] = { name: cust?.name || 'Walk-in Customer', bills: 0, revenue: 0 };
      }
      customerSales[custId].bills++;
      customerSales[custId].revenue += bill.finalAmount;
    });
    const salesByCustomerSheetData = Object.values(customerSales)
      .sort((a, b) => b.revenue - a.revenue)
      .map(c => ({ 'Customer Name': c.name, 'Number of Bills': c.bills, 'Total Revenue': c.revenue.toFixed(2) }));

    const sheets: SheetData[] = [
      { sheetName: 'Sales Data', data: salesDataSheet, columnWidths: [{wch:15},{wch:18},{wch:15},{wch:25},{wch:12},{wch:12},{wch:12},{wch:14},{wch:15},{wch:15},{wch:25},{wch:12},{wch:18}] },
      { sheetName: 'Overall Summary', data: summarySheetData, columnWidths: [{wch:25},{wch:15}] },
      { sheetName: 'Monthly Summary', data: monthlySalesSheetData, columnWidths: [{wch:15},{wch:15},{wch:15},{wch:18}] },
      { sheetName: 'Top Selling (Qty)', data: topSellingQtySheetData, columnWidths: [{wch:30},{wch:15},{wch:15}] },
      { sheetName: 'Top Selling (Rev)', data: topSellingRevSheetData, columnWidths: [{wch:30},{wch:15},{wch:15}] },
      { sheetName: 'Sales By Customer', data: salesByCustomerSheetData, columnWidths: [{wch:30},{wch:18},{wch:15}] },
    ];
    
    exportToExcel(fileName, sheets);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <h1 className="text-3xl font-semibold text-gray-800 flex items-center">
          <ChartBarIcon className="w-8 h-8 mr-2 text-primary-700" />
          Sales Report
        </h1>
        <Button onClick={handleDownloadReport} leftIcon={<DownloadIcon className="w-5 h-5"/>}>Download Excel Report</Button>
      </div>

      {/* Filters Section */}
      <div className="p-4 bg-white shadow rounded-lg">
        <h2 className="text-xl font-semibold text-gray-700 mb-4">Filters</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <InputField label="Start Date" type="date" name="startDate" value={filters.startDate} onChange={handleFilterChange} />
          <InputField label="End Date" type="date" name="endDate" value={filters.endDate} onChange={handleFilterChange} />
          <SelectField label="Customer" name="customerId" value={filters.customerId} options={customerOptions} onChange={handleFilterChange} />
          <SelectField label="Medicine" name="medicineId" value={filters.medicineId} options={medicineOptions} onChange={handleFilterChange} />
          <SelectField label="Billed By" name="billedByUserId" value={filters.billedByUserId} options={userOptions} onChange={handleFilterChange} />
        </div>
      </div>

      {/* Summary Stats Section */}
      <div className="p-4 bg-white shadow rounded-lg">
        <h2 className="text-xl font-semibold text-gray-700 mb-4">Summary Statistics (for selected period)</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 text-sm">
          <div><strong>Total Bills:</strong> {summaryStats.totalBills}</div>
          <div><strong>Total Items Sold (Units):</strong> {summaryStats.totalItemsSold}</div>
          <div><strong>Total Sales (Subtotal):</strong> ${summaryStats.totalSalesAmount.toFixed(2)}</div>
          <div><strong>Total Discount:</strong> ${summaryStats.totalDiscountGiven.toFixed(2)}</div>
          <div><strong>Total Tax:</strong> ${summaryStats.totalTaxCollected.toFixed(2)}</div>
          <div className="font-bold"><strong>Final Revenue:</strong> ${summaryStats.finalRevenue.toFixed(2)}</div>
        </div>
      </div>
      
      {/* Table Section */}
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <Table columns={salesColumns} data={filteredBills} keyExtractor={(item) => item.id} emptyStateMessage="No sales data found for the selected filters."/>
      </div>
    </div>
  );
};

export default SalesReportPage;