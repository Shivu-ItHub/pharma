
import React, { useState, useMemo } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { Bill, PurchaseRecord } from '../types';
import Button from '../components/Button';
import InputField from '../components/InputField';
import { CurrencyDollarIcon, DownloadIcon } from '../constants';
// Fix: Imported 'isBefore' and 'isAfter' from 'date-fns'
import { format, parseISO, isValid, startOfMonth, endOfMonth, eachMonthOfInterval, getMonth, getYear, isBefore, isAfter } from 'date-fns';
import { exportToExcel, SheetData } from '../utils/exportToExcel';

const ProfitLossReportPage: React.FC = () => {
  const { state } = useAppContext();
  const { bills, purchaseRecords } = state;

  const today = new Date();
  const [filters, setFilters] = useState({
    startDate: format(startOfMonth(today), 'yyyy-MM-dd'),
    endDate: format(today, 'yyyy-MM-dd'),
  });

  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const { periodSales, periodPurchases, periodProfitLoss } = useMemo(() => {
    let salesInPeriod = 0;
    let purchasesInPeriod = 0;

    const sDate = filters.startDate && isValid(parseISO(filters.startDate)) ? parseISO(filters.startDate) : null;
    let eDate = filters.endDate && isValid(parseISO(filters.endDate)) ? parseISO(filters.endDate) : null;
    if (eDate) eDate.setHours(23,59,59,999);


    bills.forEach(bill => {
      const billDate = parseISO(bill.date);
      let match = true;
      if (sDate && isBefore(billDate, sDate)) match = false;
      if (eDate && isAfter(billDate, eDate)) match = false;
      if (match) salesInPeriod += bill.finalAmount;
    });

    purchaseRecords.forEach(pr => {
      const purchaseDate = parseISO(pr.purchaseDate);
       let match = true;
      if (sDate && isBefore(purchaseDate, sDate)) match = false;
      if (eDate && isAfter(purchaseDate, eDate)) match = false;
      if (match) purchasesInPeriod += pr.totalPurchaseCost;
    });
    
    return {
      periodSales: salesInPeriod,
      periodPurchases: purchasesInPeriod,
      periodProfitLoss: salesInPeriod - purchasesInPeriod,
    };
  }, [bills, purchaseRecords, filters]);


  const handleDownloadReport = () => {
    const reportDate = format(new Date(), 'yyyy-MM-dd');
    const fileName = `ProfitLossReport_${filters.startDate}_to_${filters.endDate || reportDate}`;

    const summarySheetData = [
      { Metric: 'Selected Period', Value: `${filters.startDate} to ${filters.endDate}`},
      { Metric: 'Total Sales Revenue', Value: periodSales.toFixed(2) },
      { Metric: 'Total Purchase Expenditures', Value: periodPurchases.toFixed(2) },
      { Metric: 'Gross Profit / (Loss)', Value: periodProfitLoss.toFixed(2) },
    ];
    
    // Monthly Breakdown
    const monthlyData: { 
      [month: string]: { sales: number, purchases: number, profit: number } 
    } = {};

    const sDateValid = filters.startDate && isValid(parseISO(filters.startDate)) ? parseISO(filters.startDate) : startOfMonth(new Date(0)); // a very early date
    const eDateValid = filters.endDate && isValid(parseISO(filters.endDate)) ? endOfMonth(parseISO(filters.endDate)) : endOfMonth(new Date());


    if (isValid(sDateValid) && isValid(eDateValid) && !isBefore(eDateValid,sDateValid)) {
        const monthsInInterval = eachMonthOfInterval({ start: sDateValid, end: eDateValid });
        monthsInInterval.forEach(monthStart => {
            const monthYear = format(monthStart, 'yyyy-MM');
            monthlyData[monthYear] = { sales: 0, purchases: 0, profit: 0 };
        });
    }


    bills.forEach(bill => {
      const billDate = parseISO(bill.date);
      if(isValid(billDate) && billDate >= sDateValid && billDate <= eDateValid) {
        const monthYear = format(billDate, 'yyyy-MM');
        if (monthlyData[monthYear]) {
          monthlyData[monthYear].sales += bill.finalAmount;
        }
      }
    });

    purchaseRecords.forEach(pr => {
      const purchaseDate = parseISO(pr.purchaseDate);
      if(isValid(purchaseDate) && purchaseDate >= sDateValid && purchaseDate <= eDateValid) {
        const monthYear = format(purchaseDate, 'yyyy-MM');
         if (monthlyData[monthYear]) {
            monthlyData[monthYear].purchases += pr.totalPurchaseCost;
        }
      }
    });
    
    const monthlyBreakdownSheetData = Object.entries(monthlyData).map(([month, data]) => ({
      Month: month,
      'Total Sales': data.sales.toFixed(2),
      'Total Purchases': data.purchases.toFixed(2),
      'Profit / (Loss)': (data.sales - data.purchases).toFixed(2),
    })).sort((a,b) => a.Month.localeCompare(b.Month));


    const sheets: SheetData[] = [
      { sheetName: 'P&L Summary', data: summarySheetData, columnWidths: [{wch:30},{wch:15}] },
      { sheetName: 'Monthly P&L Breakdown', data: monthlyBreakdownSheetData, columnWidths: [{wch:15},{wch:15},{wch:18},{wch:18}] },
    ];
    
    exportToExcel(fileName, sheets);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <h1 className="text-3xl font-semibold text-gray-800 flex items-center">
          <CurrencyDollarIcon className="w-8 h-8 mr-2 text-primary-700" />
          Profit &amp; Loss Report
        </h1>
        <Button onClick={handleDownloadReport} leftIcon={<DownloadIcon className="w-5 h-5"/>}>Download Excel Report</Button>
      </div>

      <div className="p-4 bg-white shadow rounded-lg">
        <h2 className="text-xl font-semibold text-gray-700 mb-4">Filters</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <InputField label="Start Date" type="date" name="startDate" value={filters.startDate} onChange={handleFilterChange} />
          <InputField label="End Date" type="date" name="endDate" value={filters.endDate} onChange={handleFilterChange} />
        </div>
      </div>

      <div className="p-6 bg-white shadow rounded-lg">
        <h2 className="text-xl font-semibold text-gray-700 mb-4">Profit &amp; Loss Summary (for selected period)</h2>
        <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                    <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Metric</th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                    </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                    <tr>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">Total Sales Revenue</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600 text-right">${periodSales.toFixed(2)}</td>
                    </tr>
                    <tr>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">Total Purchase Expenditures</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600 text-right">(${periodPurchases.toFixed(2)})</td>
                    </tr>
                    <tr className="bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-800">Gross Profit / (Loss)</td>
                        <td className={`px-6 py-4 whitespace-nowrap text-sm font-bold text-right ${periodProfitLoss >= 0 ? 'text-green-700' : 'text-red-700'}`}>
                            ${periodProfitLoss.toFixed(2)}
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <p className="text-xs text-gray-500 mt-2">
            Note: This report provides a high-level overview based on total sales revenue and total purchase costs within the selected period. It does not use specific Cost of Goods Sold (COGS) per item accounting.
        </p>
      </div>
    </div>
  );
};

export default ProfitLossReportPage;