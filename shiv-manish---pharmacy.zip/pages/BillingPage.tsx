
import React, { useState, useEffect, useMemo } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { Medicine, Customer, Bill, BillItem, UserRole } from '../types';
import Button from '../components/Button';
import InputField from '../components/InputField';
import SelectField from '../components/SelectField';
import BillReceiptModal from '../components/BillReceiptModal'; // Added
import { TrashIcon, PlusCircleIcon, PrinterIcon, ExclamationTriangleIcon } from '../constants';
import { isBefore, parseISO } from 'date-fns';

const BillingPage: React.FC = () => {
  const { state, dispatch } = useAppContext();
  const { medicines, customers, currentUser } = state;

  const [selectedCustomerId, setSelectedCustomerId] = useState<string | undefined>(undefined);
  const [currentBillItems, setCurrentBillItems] = useState<BillItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'Card' | 'UPI' | 'Other'>('Cash');
  const [discount, setDiscount] = useState<number>(0);
  
  const [showReceiptModal, setShowReceiptModal] = useState(false); 
  const [lastFinalizedBill, setLastFinalizedBill] = useState<Bill | null>(null); 

  const availableMedicines = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Compare dates only, not times

    return medicines.filter(med => {
      const expiryDate = new Date(med.expiryDate);
      expiryDate.setHours(0,0,0,0); // Ensure we are comparing dates correctly

      return med.quantityInStock > 0 &&
             !isBefore(expiryDate, today) && // Medicine is not expired
             (med.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
              med.batchNumber.toLowerCase().includes(searchTerm.toLowerCase()));
    });
  }, [medicines, searchTerm]);

  const customerOptions = useMemo(() => customers.map(c => ({ value: c.id, label: `${c.name} (${c.contact})` })), [customers]);

  const addMedicineToBill = (medicine: Medicine) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const expiryDate = new Date(medicine.expiryDate);
    expiryDate.setHours(0,0,0,0);

    if (isBefore(expiryDate, today)) {
      alert(`${medicine.name} (Batch: ${medicine.batchNumber}) is EXPIRED and cannot be sold.`);
      return;
    }

    if (medicine.quantityInStock <= 0) {
      alert(`${medicine.name} is out of stock.`);
      return;
    }
    
    const existingItemIndex = currentBillItems.findIndex(item => item.medicineId === medicine.id);
    if (existingItemIndex > -1) {
      const updatedItems = [...currentBillItems];
      if (updatedItems[existingItemIndex].quantity < medicine.quantityInStock) {
        updatedItems[existingItemIndex].quantity += 1;
        updatedItems[existingItemIndex].totalPrice = updatedItems[existingItemIndex].quantity * updatedItems[existingItemIndex].unitPrice;
        setCurrentBillItems(updatedItems);
      } else {
        alert(`Cannot add more ${medicine.name}. Max stock available: ${medicine.quantityInStock}`);
      }
    } else {
      setCurrentBillItems([...currentBillItems, {
        medicineId: medicine.id,
        medicineName: medicine.name,
        quantity: 1,
        unitPrice: medicine.salePrice,
        totalPrice: medicine.salePrice,
      }]);
    }
    setSearchTerm(''); 
  };

  const updateItemQuantity = (medicineId: string, newQuantity: number) => {
    const medicine = medicines.find(m => m.id === medicineId);
    if (!medicine) return;

    if (newQuantity <= 0) {
      removeBillItem(medicineId);
      return;
    }
    if (newQuantity > medicine.quantityInStock) {
      alert(`Cannot set quantity to ${newQuantity} for ${medicine.name}. Max stock available: ${medicine.quantityInStock}`);
      newQuantity = medicine.quantityInStock;
    }

    setCurrentBillItems(currentBillItems.map(item =>
      item.medicineId === medicineId
        ? { ...item, quantity: newQuantity, totalPrice: newQuantity * item.unitPrice }
        : item
    ));
  };

  const removeBillItem = (medicineId: string) => {
    setCurrentBillItems(currentBillItems.filter(item => item.medicineId !== medicineId));
  };

  const subTotal = useMemo(() => currentBillItems.reduce((sum, item) => sum + item.totalPrice, 0), [currentBillItems]);
  const taxRate = 0.05; 
  const taxAmount = subTotal * taxRate;
  const finalAmount = subTotal + taxAmount - discount;

  const handleFinalizeBill = () => {
    if (!currentUser) {
      alert("No user logged in. Cannot finalize bill.");
      return;
    }
    if (currentBillItems.length === 0) {
      alert("Cannot finalize an empty bill.");
      return;
    }

    const billId = `BILL-${Date.now()}`;
    const newBill: Bill = {
      id: billId,
      billNumber: billId, 
      customerId: selectedCustomerId,
      customerName: customers.find(c => c.id === selectedCustomerId)?.name,
      items: currentBillItems,
      totalAmount: subTotal,
      discount: discount,
      taxAmount: taxAmount,
      finalAmount: finalAmount,
      date: new Date().toISOString(),
      paymentMethod: paymentMethod,
      billedByUserId: currentUser.id,
      billedByUserName: currentUser.name,
    };

    dispatch({ type: 'ADD_BILL', payload: newBill });
    currentBillItems.forEach(item => {
      dispatch({ type: 'UPDATE_MEDICINE_STOCK', payload: { medicineId: item.medicineId, quantityChange: item.quantity } });
    });

    setLastFinalizedBill(newBill); 
    setShowReceiptModal(true); 

    // Reset for next bill, but AFTER showing modal or handling print
    setCurrentBillItems([]);
    setSelectedCustomerId(undefined);
    setSearchTerm('');
    setDiscount(0);
    setPaymentMethod('Cash');
  };
  
  const closeReceiptModalAndReset = () => { 
    setShowReceiptModal(false);
    setLastFinalizedBill(null);
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-semibold text-gray-800">New Bill</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="p-6 bg-white shadow rounded-lg">
            <h2 className="text-xl font-semibold text-gray-700 mb-4">Add Medicines</h2>
            <InputField
              placeholder="Search medicine by name or batch..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            {searchTerm && availableMedicines.length > 0 && (
              <ul className="mt-2 border border-gray-300 rounded-md max-h-60 overflow-y-auto bg-white shadow-lg z-10">
                {availableMedicines.map(med => (
                  <li 
                    key={med.id} 
                    className="p-3 hover:bg-primary-100 cursor-pointer border-b last:border-b-0"
                    onClick={() => addMedicineToBill(med)}
                  >
                    <div className="flex justify-between">
                      <span>{med.name} ({med.batchNumber})</span>
                      <span className="text-sm text-gray-500">Stock: {med.quantityInStock} | Price: ${med.salePrice.toFixed(2)}</span>
                    </div>
                  </li>
                ))}
              </ul>
            )}
             {searchTerm && availableMedicines.length === 0 && (
                <p className="mt-2 text-sm text-gray-500">No non-expired medicines found matching your search or out of stock.</p>
            )}
          </div>

          <div className="p-6 bg-white shadow rounded-lg">
            <h2 className="text-xl font-semibold text-gray-700 mb-4">Current Bill Items</h2>
            {currentBillItems.length === 0 ? (
              <p className="text-gray-500">No items added to the bill yet.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Medicine</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Qty</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {currentBillItems.map(item => (
                      <tr key={item.medicineId}>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700">{item.medicineName}</td>
                        <td className="px-4 py-2">
                          <InputField
                            type="number"
                            min="1"
                            max={medicines.find(m => m.id === item.medicineId)?.quantityInStock.toString()}
                            value={item.quantity}
                            onChange={(e) => updateItemQuantity(item.medicineId, parseInt(e.target.value))}
                            className="w-20 text-sm p-1"
                            containerClassName="m-0"
                          />
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700">${item.unitPrice.toFixed(2)}</td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700">${item.totalPrice.toFixed(2)}</td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm">
                          <Button size="sm" variant="danger" onClick={() => removeBillItem(item.medicineId)}><TrashIcon className="w-4 h-4"/></Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        <div className="lg:col-span-1 space-y-6">
          <div className="p-6 bg-white shadow rounded-lg">
            <h2 className="text-xl font-semibold text-gray-700 mb-4">Customer Details</h2>
            <SelectField
              label="Select Customer (Optional)"
              options={[{value: '', label: 'Walk-in Customer'}, ...customerOptions]}
              value={selectedCustomerId || ''}
              onChange={(e) => setSelectedCustomerId(e.target.value || undefined)}
              placeholder="Select or Walk-in"
            />
          </div>

          <div className="p-6 bg-white shadow rounded-lg">
            <h2 className="text-xl font-semibold text-gray-700 mb-4">Payment Summary</h2>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span>Subtotal:</span> <span>${subTotal.toFixed(2)}</span></div>
              <div className="flex justify-between"><span>Tax ({ (taxRate * 100).toFixed(0) }%):</span> <span>${taxAmount.toFixed(2)}</span></div>
              <div className="flex justify-between items-center">
                <span>Discount:</span>
                <InputField 
                  type="number" 
                  value={discount} 
                  onChange={(e) => setDiscount(parseFloat(e.target.value) || 0)} 
                  className="w-24 text-sm p-1 text-right"
                  containerClassName="m-0 inline-block"
                />
              </div>
              <hr className="my-2"/>
              <div className="flex justify-between font-bold text-lg"><span>Final Amount:</span> <span>${finalAmount.toFixed(2)}</span></div>
            </div>
            <SelectField
              label="Payment Method"
              options={[
                { value: 'Cash', label: 'Cash' },
                { value: 'Card', label: 'Card' },
                { value: 'UPI', label: 'UPI' },
                { value: 'Other', label: 'Other' },
              ]}
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value as any)}
              containerClassName="mt-4"
            />
            <Button 
              onClick={handleFinalizeBill} 
              className="w-full mt-6" 
              disabled={currentBillItems.length === 0}
              leftIcon={<PlusCircleIcon className="w-5 h-5"/>}
            >
              Finalize Bill &amp; View Receipt
            </Button>
          </div>
        </div>
      </div>
      <BillReceiptModal 
        isOpen={showReceiptModal} 
        onClose={closeReceiptModalAndReset} 
        bill={lastFinalizedBill} 
      />
    </div>
  );
};

export default BillingPage;
