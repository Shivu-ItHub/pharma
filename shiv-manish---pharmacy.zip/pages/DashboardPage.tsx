import React, { useMemo, useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
// Fix: Changed NewBatchData to NewBatchInfo
import { Medicine, Customer, Bill, UserRole, TableColumn, ReorderStatus, ReorderRequest, NewBatchInfo, PurchaseRecord } from '../types';
import { PillIcon, UsersIcon, ShoppingCartIcon, ExclamationTriangleIcon, ChartBarIcon, CurrencyDollarIcon, ShoppingBagIcon, RefreshCwIcon, ClipboardListIcon, ExternalLinkIcon } from '../constants';
import { LOW_STOCK_THRESHOLD, EXPIRY_WARNING_DAYS } from '../constants';
import { differenceInDays, isBefore, format, isWithinInterval } from 'date-fns';
import ReorderModal from '../components/ReorderModal';
import Button from '../components/Button';
import Table from '../components/Table';
import { Link } from 'react-router-dom';
import StatCard from '../components/StatCard'; // Import standalone StatCard
import MonthlySalesModal from '../components/MonthlySalesModal'; // Import new modal
import MonthlyPurchasesModal from '../components/MonthlyPurchasesModal'; // Import new modal


interface SimpleBarChartProps {
  data: { label: string; value: number }[];
  title: string;
  barColorClass?: string;
}

const SimpleBarChart: React.FC<SimpleBarChartProps> = ({ data, title, barColorClass = 'bg-primary-500' }) => {
  const maxValue = Math.max(...data.map(item => item.value), 0);

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h2 className="text-xl font-semibold text-gray-700 mb-4">{title}</h2>
      {data.length === 0 ? (
        <p className="text-gray-500">No data available for this chart.</p>
      ) : (
        <div className="space-y-3">
          {data.map(item => (
            <div key={item.label} className="flex items-center">
              <div className="w-1/3 text-sm text-gray-600 truncate pr-2" title={item.label}>{item.label}</div>
              <div className="w-2/3 flex items-center">
                <div 
                  className={`rounded-sm ${barColorClass} transition-all duration-500 ease-out`}
                  style={{ height: '20px', width: `${maxValue > 0 ? (item.value / maxValue) * 100 : 0}%` }}
                ></div>
                <span className="ml-2 text-sm font-medium text-gray-700">{item.value}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};


const DashboardPage: React.FC = () => {
  const { state, dispatch } = useAppContext();
  const { medicines, customers, bills, currentUser, reorderRequests, purchaseRecords } = state;

  const [isReorderModalOpen, setIsReorderModalOpen] = useState(false);
  const [reorderingMedicine, setReorderingMedicine] = useState<Medicine | null>(null);
  const [isMonthlySalesModalOpen, setIsMonthlySalesModalOpen] = useState(false);
  const [isMonthlyPurchasesModalOpen, setIsMonthlyPurchasesModalOpen] = useState(false);

  const todayStr = format(new Date(), 'yyyy-MM-dd');
  const totalSalesTodayCount = bills.filter(bill => format(new Date(bill.date), 'yyyy-MM-dd') === todayStr).length;
  const totalRevenueAllTime = bills.reduce((sum, bill) => sum + bill.finalAmount, 0);
  
  const lowStockMedicinesList = useMemo(() => medicines.filter(
    (med) => med.quantityInStock < (med.lowStockThreshold || LOW_STOCK_THRESHOLD) && !isBefore(new Date(med.expiryDate), new Date())
  ), [medicines]);
  const lowStockMedicinesCount = lowStockMedicinesList.length;
  
  const pendingReorderRequestsCount = useMemo(() => 
    reorderRequests.filter(req => req.status === ReorderStatus.PENDING).length,
  [reorderRequests]);


  const expiringSoonMedicines = useMemo(() => {
    return medicines.filter((med) => {
      const expiryDate = new Date(med.expiryDate);
      const today = new Date();
      return isBefore(expiryDate, today) || differenceInDays(expiryDate, today) <= EXPIRY_WARNING_DAYS;
    }).sort((a,b) => differenceInDays(new Date(a.expiryDate), new Date()) - differenceInDays(new Date(b.expiryDate), new Date()));
  }, [medicines]);

  const expiringSoonMedicinesCount = expiringSoonMedicines.length;
  const expiringSoonTopList = expiringSoonMedicines.slice(0,3);

  const topSellingMedicines = useMemo(() => {
    const salesCount: { [medicineId: string]: { name: string; quantity: number } } = {};
    bills.forEach(bill => {
      bill.items.forEach(item => {
        if (salesCount[item.medicineId]) {
          salesCount[item.medicineId].quantity += item.quantity;
        } else {
          const medicine = medicines.find(m => m.id === item.medicineId);
          salesCount[item.medicineId] = {
            name: medicine ? medicine.name : `ID: ${item.medicineId}`,
            quantity: item.quantity,
          };
        }
      });
    });
    return Object.entries(salesCount)
      .map(([_, data]) => ({ label: data.name, value: data.quantity }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5);
  }, [bills, medicines]);

  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
  const currentMonthName = format(now, 'MMMM yyyy');

  const billsThisMonth = useMemo(() => bills.filter(bill => {
      const billDate = new Date(bill.date);
      return isWithinInterval(billDate, { start: monthStart, end: monthEnd });
  }), [bills, monthStart, monthEnd]);

  const purchasesThisMonthData = useMemo(() => purchaseRecords.filter(pr => 
    isWithinInterval(new Date(pr.purchaseDate), { start: monthStart, end: monthEnd })
  ), [purchaseRecords, monthStart, monthEnd]);

  const { totalSalesThisMonth, totalPurchasesThisMonth, profitLossThisMonth } = useMemo(() => {
    if (currentUser?.role !== UserRole.ADMIN) {
      return { totalSalesThisMonth: 0, totalPurchasesThisMonth: 0, profitLossThisMonth: 0 };
    }
    const sales = billsThisMonth.reduce((sum, bill) => sum + bill.finalAmount, 0);
    const purchases = purchasesThisMonthData.reduce((sum, pr) => sum + pr.totalPurchaseCost, 0);

    return { 
      totalSalesThisMonth: sales, 
      totalPurchasesThisMonth: purchases, 
      profitLossThisMonth: sales - purchases 
    };
  }, [billsThisMonth, purchasesThisMonthData, currentUser]);

  const handleReorderClick = (medicine: Medicine) => {
    setReorderingMedicine(medicine);
    setIsReorderModalOpen(true);
  };

  // Fix: Changed NewBatchData to NewBatchInfo
  const handleConfirmReorder = (medicine: Medicine, quantity: number, batchDetails: NewBatchInfo) => {
    if (!currentUser || currentUser.role !== UserRole.ADMIN) { // Ensure only admin can confirm
      alert("Error: Only Admins can create re-order requests.");
      return;
    }
    
    const newReorderRequest: ReorderRequest = {
      id: `RO-${Date.now()}`,
      medicineId: medicine.id,
      medicineName: medicine.name,
      supplier: medicine.supplier,
      quantityOrdered: quantity,
      requestedByUserId: currentUser.id,
      requestedByUserName: currentUser.name,
      requestDate: new Date().toISOString(),
      status: ReorderStatus.PENDING,
      newBatchDetails: batchDetails,
    };
    dispatch({ type: 'ADD_REORDER_REQUEST', payload: newReorderRequest });
    
    const alertMessage = `PENDING re-order request created for ${quantity} of "${medicine.name}" (New Batch: ${batchDetails.batchNumber}).\n` +
                         `Admin needs to mark it as 'Completed' to update stock and medicine details.`;
    alert(alertMessage);
    setIsReorderModalOpen(false);
    setReorderingMedicine(null);
  };
  
  const reorderColumns: TableColumn<Medicine>[] = [
    { key: 'name', header: 'Name' },
    { key: 'quantityInStock', header: 'Current Stock' },
    { key: 'lowStockThreshold', header: 'Threshold', render: item => item.lowStockThreshold || LOW_STOCK_THRESHOLD },
    { key: 'supplier', header: 'Supplier', render: item => item.supplier || 'N/A' },
    {
      key: 'actions',
      header: 'Action',
      render: (item) => {
        const existingPendingRequest = reorderRequests.find(
            req => req.medicineId === item.id && req.status === ReorderStatus.PENDING
        );

        if (existingPendingRequest) {
            return (
                <Link to="/reorders">
                    <Button
                        size="sm"
                        variant="secondary" // Or another appropriate variant
                        leftIcon={<ExternalLinkIcon className="w-4 h-4" />}
                        title={`Pending order ID: ${existingPendingRequest.id}`}
                    >
                        View Pending Order
                    </Button>
                </Link>
            );
        } else {
            return (
                <Button
                  size="sm"
                  variant="warning"
                  onClick={() => handleReorderClick(item)}
                  leftIcon={<RefreshCwIcon className="w-4 h-4" />}
                  title="Initiate new re-order for this medicine"
                >
                  Initiate Re-order
                </Button>
            );
        }
      },
    },
  ];

  const isAdmin = currentUser?.role === UserRole.ADMIN;

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-semibold text-gray-800">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Total Medicines" value={medicines.length} icon={<PillIcon className="w-8 h-8 text-white"/>} colorClass="bg-blue-500" />
        <StatCard title="Total Customers" value={customers.length} icon={<UsersIcon className="w-8 h-8 text-white"/>} colorClass="bg-green-500" />
        <StatCard title="Sales Today (Count)" value={totalSalesTodayCount} icon={<ShoppingCartIcon className="w-8 h-8 text-white"/>} colorClass="bg-indigo-500" />
        <StatCard title="Total Revenue (All Time)" value={`$${totalRevenueAllTime.toFixed(2)}`} icon={<ChartBarIcon className="w-8 h-8 text-white"/>} colorClass="bg-purple-500" />
      </div>

      {isAdmin && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <StatCard 
                title="Sales This Month" 
                value={`$${totalSalesThisMonth.toFixed(2)}`} 
                icon={<ShoppingCartIcon className="w-8 h-8 text-white"/>} 
                colorClass="bg-sky-500"
                tooltip={`Click to view sales details for ${currentMonthName}`}
                onClick={() => setIsMonthlySalesModalOpen(true)}
            />
            <StatCard 
                title="Purchases This Month" 
                value={`$${totalPurchasesThisMonth.toFixed(2)}`} 
                icon={<ShoppingBagIcon className="w-8 h-8 text-white"/>} 
                colorClass="bg-amber-500"
                tooltip={`Click to view purchase details for ${currentMonthName}`}
                onClick={() => setIsMonthlyPurchasesModalOpen(true)}
            />
            <StatCard 
                title="Profit/Loss This Month" 
                value={`${profitLossThisMonth >= 0 ? '$' : '-$'}${Math.abs(profitLossThisMonth).toFixed(2)}`} 
                icon={<CurrencyDollarIcon className="w-8 h-8 text-white"/>} 
                colorClass={profitLossThisMonth >=0 ? "bg-emerald-500" : "bg-rose-500"}
                tooltip="Calculated as: Sales This Month - Purchases This Month"
            />
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
           <SimpleBarChart data={topSellingMedicines} title="Top 5 Selling Medicines (by Quantity)" barColorClass="bg-teal-500" />
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-lg space-y-4">
          <h2 className="text-xl font-semibold text-gray-700 mb-2">Inventory & Re-order Alerts</h2>
            <StatCard 
                title="Low Stock Items" 
                value={lowStockMedicinesCount} 
                icon={<ExclamationTriangleIcon className="w-8 h-8 text-white"/>} 
                colorClass="bg-yellow-500"
                tooltip="Medicines below their defined low stock threshold (and not expired)."
            />
            { isAdmin && (
                <StatCard 
                    title="Pending Re-orders" 
                    value={pendingReorderRequestsCount} 
                    icon={<ClipboardListIcon className="w-8 h-8 text-white"/>} 
                    colorClass="bg-orange-500"
                    tooltip="Re-order requests awaiting Admin completion."
                    linkTo="/reorders"
                />
            )}
            <div className={`p-4 rounded-md ${expiringSoonMedicinesCount > 0 ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
               <div className="flex items-start">
                <ExclamationTriangleIcon className={`w-6 h-6 mr-3 flex-shrink-0 ${expiringSoonMedicinesCount > 0 ? 'text-red-500' : 'text-green-500'}`} />
                <div>
                  <p className="font-medium">Expiring Soon / Expired</p>
                  <p className="text-2xl font-bold">{expiringSoonMedicinesCount}</p>
                </div>
              </div>
              {expiringSoonMedicinesCount > 0 && (
                <ul className="mt-2 text-sm list-disc list-inside pl-2">
                  {expiringSoonTopList.map(med => (
                    <li key={med.id} className={isBefore(new Date(med.expiryDate), new Date()) ? 'text-red-700 font-semibold' : ''}>
                      {med.name} (Expires: {format(new Date(med.expiryDate), 'P')})
                       - Stock: {med.quantityInStock}
                    </li>
                  ))}
                </ul>
              )}
            </div>
        </div>
      </div>
      
      {isAdmin && ( // Only show Re-order Central to Admins
        <div className="bg-white p-6 rounded-lg shadow-lg">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-gray-700 flex items-center">
              <RefreshCwIcon className="w-6 h-6 mr-2 text-primary-600" />
              Re-order Central: Low Stock Items
            </h2>
            <Link to="/reorders">
                <Button variant="primary" size="sm" leftIcon={<ClipboardListIcon className="w-4 h-4"/>}>
                    Manage All Re-orders ({pendingReorderRequestsCount} Pending)
                </Button>
            </Link>
          </div>
          {lowStockMedicinesList.length > 0 ? (
            <Table 
              columns={reorderColumns} 
              data={lowStockMedicinesList} 
              keyExtractor={(item) => item.id} 
              emptyStateMessage="All non-expired medicines are above their low stock threshold."
            />
          ) : (
            <p className="text-gray-500">All non-expired medicines are currently above their low stock thresholds. No re-orders needed at this moment.</p>
          )}
        </div>
      )}

      <div className="bg-white p-6 rounded-lg shadow-lg">
        <h2 className="text-xl font-semibold text-gray-700 mb-4">Recent Bills (Last 5)</h2>
        {bills.length > 0 ? (
          <ul className="divide-y divide-gray-200">
            {bills.slice(-5).reverse().map(bill => (
              <li key={bill.id} className="py-3">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium text-primary-600">Bill #{bill.billNumber}</p>
                    <p className="text-xs text-gray-500">{bill.customerName || 'Walk-in Customer'} - {format(new Date(bill.date), 'Pp')}</p>
                  </div>
                  <p className="text-sm font-semibold text-gray-700">${bill.finalAmount.toFixed(2)}</p>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-gray-500">No bills recorded yet.</p>
        )}
      </div>

      {isAdmin && (
        <ReorderModal 
            isOpen={isReorderModalOpen}
            onClose={() => { setIsReorderModalOpen(false); setReorderingMedicine(null); }}
            medicine={reorderingMedicine}
            onConfirmReorder={handleConfirmReorder}
        />
      )}
      
      {isAdmin && (
        <>
          <MonthlySalesModal
            isOpen={isMonthlySalesModalOpen}
            onClose={() => setIsMonthlySalesModalOpen(false)}
            bills={billsThisMonth}
            monthName={currentMonthName}
          />
          <MonthlyPurchasesModal
            isOpen={isMonthlyPurchasesModalOpen}
            onClose={() => setIsMonthlyPurchasesModalOpen(false)}
            purchaseRecords={purchasesThisMonthData}
            monthName={currentMonthName}
          />
        </>
      )}
    </div>
  );
};

export default DashboardPage;