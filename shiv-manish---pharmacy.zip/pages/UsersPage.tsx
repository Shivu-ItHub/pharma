
import React, { useState, useMemo } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { User, UserRole, TableColumn } from '../types';
import Table from '../components/Table';
import Modal from '../components/Modal';
import Button from '../components/Button';
import InputField from '../components/InputField';
import SelectField from '../components/SelectField';
import ConfirmationDialog from '../components/ConfirmationDialog';
import { PlusCircleIcon, PencilIcon, TrashIcon } from '../constants';

const initialUserFormState: Omit<User, 'id'> = {
  username: '',
  password: '',
  role: UserRole.CASHIER,
  name: '',
};

const UsersPage: React.FC = () => {
  const { state, dispatch } = useAppContext();
  const { users, currentUser } = state;
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [userForm, setUserForm] = useState<Omit<User, 'id'>>(initialUserFormState);
  
  const [isConfirmDeleteDialogOpen, setIsConfirmDeleteDialogOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);

  if (currentUser?.role !== UserRole.ADMIN) {
    return <div className="p-4 text-red-500">Access Denied. Only Admins can manage users.</div>;
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setUserForm(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingUser) {
      // For editing, password field might be empty if not changing
      const payload = { ...editingUser, ...userForm };
      if (!userForm.password) delete payload.password; // Don't update password if field is empty
      dispatch({ type: 'UPDATE_USER', payload });
    } else {
      if (!userForm.password) {
        alert("Password is required for new users.");
        return;
      }
      dispatch({ type: 'ADD_USER', payload: { id: Date.now().toString(), ...userForm } });
    }
    closeModal();
  };

  const openModal = (user?: User) => {
    if (user) {
      setEditingUser(user);
      setUserForm({ ...user, password: '' }); // Clear password field for editing
    } else {
      setEditingUser(null);
      setUserForm(initialUserFormState);
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingUser(null);
    setUserForm(initialUserFormState);
  };

  const handleDelete = (user: User) => {
    if (user.id === currentUser.id) {
        alert("You cannot delete your own account.");
        return;
    }
    setUserToDelete(user);
    setIsConfirmDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (userToDelete) {
      dispatch({ type: 'DELETE_USER', payload: userToDelete.id });
    }
    setIsConfirmDeleteDialogOpen(false);
    setUserToDelete(null);
  };

  const columns: TableColumn<User>[] = [
    { key: 'name', header: 'Name' },
    { key: 'username', header: 'Username' },
    { key: 'role', header: 'Role' },
    { 
      key: 'actions', 
      header: 'Actions', 
      render: (item: User) => (
        <div className="space-x-2">
          <Button size="sm" variant="secondary" onClick={() => openModal(item)} leftIcon={<PencilIcon className="w-4 h-4"/>}>Edit</Button>
          {item.id !== currentUser?.id && ( // Prevent deleting self
             <Button size="sm" variant="danger" onClick={() => handleDelete(item)} leftIcon={<TrashIcon className="w-4 h-4"/>}>Delete</Button>
          )}
        </div>
      )
    }
  ];

  const roleOptions = Object.values(UserRole).map(role => ({ value: role, label: role }));

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-semibold text-gray-800">Manage Users</h1>
        <Button onClick={() => openModal()} leftIcon={<PlusCircleIcon className="w-5 h-5"/>}>Add User</Button>
      </div>

      <Table columns={columns} data={users} keyExtractor={(item) => item.id} />

      <Modal isOpen={isModalOpen} onClose={closeModal} title={editingUser ? 'Edit User' : 'Add New User'}>
        <form onSubmit={handleSubmit} className="space-y-4">
          <InputField label="Full Name" name="name" value={userForm.name} onChange={handleInputChange} required />
          <InputField label="Username" name="username" value={userForm.username} onChange={handleInputChange} required />
          <InputField label="Password" name="password" type="password" placeholder={editingUser ? "Leave blank to keep current password" : ""} onChange={handleInputChange} required={!editingUser} />
          <SelectField label="Role" name="role" value={userForm.role} onChange={handleInputChange} options={roleOptions} required />
          
          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="secondary" onClick={closeModal}>Cancel</Button>
            <Button type="submit">{editingUser ? 'Save Changes' : 'Add User'}</Button>
          </div>
        </form>
      </Modal>

      <ConfirmationDialog
        isOpen={isConfirmDeleteDialogOpen}
        onClose={() => setIsConfirmDeleteDialogOpen(false)}
        onConfirm={confirmDelete}
        title="Confirm Deletion"
        message={`Are you sure you want to delete user ${userToDelete?.username}? This action cannot be undone.`}
      />
    </div>
  );
};

export default UsersPage;
