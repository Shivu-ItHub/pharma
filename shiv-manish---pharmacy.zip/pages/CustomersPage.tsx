
import React, { useState, useMemo } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { Customer, TableColumn } from '../types';
import Table from '../components/Table';
import Modal from '../components/Modal';
import Button from '../components/Button';
import InputField from '../components/InputField';
import SelectField from '../components/SelectField';
import ConfirmationDialog from '../components/ConfirmationDialog';
import { PlusCircleIcon, PencilIcon, TrashIcon } from '../constants';

const initialCustomerFormState: Omit<Customer, 'id'> = {
  name: '',
  contact: '',
  age: undefined,
  gender: undefined,
  address: '',
};

const CustomersPage: React.FC = () => {
  const { state, dispatch } = useAppContext();
  const { customers } = state;
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [customerForm, setCustomerForm] = useState<Omit<Customer, 'id'>>(initialCustomerFormState);
  const [searchTerm, setSearchTerm] = useState('');

  const [isConfirmDeleteDialogOpen, setIsConfirmDeleteDialogOpen] = useState(false);
  const [customerToDelete, setCustomerToDelete] = useState<Customer | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const val = type === 'number' ? (value ? parseInt(value) : undefined) : value;
    setCustomerForm(prev => ({ ...prev, [name]: val === '' && type === 'number' ? undefined : val }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingCustomer) {
      dispatch({ type: 'UPDATE_CUSTOMER', payload: { ...editingCustomer, ...customerForm } });
    } else {
      dispatch({ type: 'ADD_CUSTOMER', payload: { id: Date.now().toString(), ...customerForm } });
    }
    closeModal();
  };

  const openModal = (customer?: Customer) => {
    if (customer) {
      setEditingCustomer(customer);
      setCustomerForm(customer);
    } else {
      setEditingCustomer(null);
      setCustomerForm(initialCustomerFormState);
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingCustomer(null);
    setCustomerForm(initialCustomerFormState);
  };

  const handleDelete = (customer: Customer) => {
    setCustomerToDelete(customer);
    setIsConfirmDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (customerToDelete) {
      dispatch({ type: 'DELETE_CUSTOMER', payload: customerToDelete.id });
    }
    setIsConfirmDeleteDialogOpen(false);
    setCustomerToDelete(null);
  };

  const filteredCustomers = useMemo(() => {
    return customers.filter(cust =>
      cust.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cust.contact.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [customers, searchTerm]);

  const columns: TableColumn<Customer>[] = [
    { key: 'name', header: 'Name' },
    { key: 'contact', header: 'Contact' },
    { key: 'age', header: 'Age' },
    { key: 'gender', header: 'Gender' },
    { key: 'address', header: 'Address' },
    { 
      key: 'actions', 
      header: 'Actions', 
      render: (item: Customer) => (
        <div className="space-x-2">
          <Button size="sm" variant="secondary" onClick={() => openModal(item)} leftIcon={<PencilIcon className="w-4 h-4"/>}>Edit</Button>
          <Button size="sm" variant="danger" onClick={() => handleDelete(item)} leftIcon={<TrashIcon className="w-4 h-4"/>}>Delete</Button>
        </div>
      )
    }
  ];

  const genderOptions = [
    { value: 'Male', label: 'Male' },
    { value: 'Female', label: 'Female' },
    { value: 'Other', label: 'Other' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-semibold text-gray-800">Customers</h1>
        <Button onClick={() => openModal()} leftIcon={<PlusCircleIcon className="w-5 h-5"/>}>Add Customer</Button>
      </div>

      <div className="p-4 bg-white shadow rounded-md">
        <InputField
            placeholder="Search customers by name or contact..."
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <Table columns={columns} data={filteredCustomers} keyExtractor={(item) => item.id} />

      <Modal isOpen={isModalOpen} onClose={closeModal} title={editingCustomer ? 'Edit Customer' : 'Add New Customer'}>
        <form onSubmit={handleSubmit} className="space-y-4">
          <InputField label="Name" name="name" value={customerForm.name} onChange={handleInputChange} required />
          <InputField label="Contact Number" name="contact" value={customerForm.contact} onChange={handleInputChange} required />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InputField label="Age" name="age" type="number" value={customerForm.age || ''} onChange={handleInputChange} />
            <SelectField label="Gender" name="gender" value={customerForm.gender || ''} onChange={handleInputChange} options={genderOptions} placeholder="Select Gender" />
          </div>
          <InputField label="Address" name="address" value={customerForm.address || ''} onChange={handleInputChange} />
          
          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="secondary" onClick={closeModal}>Cancel</Button>
            <Button type="submit">{editingCustomer ? 'Save Changes' : 'Add Customer'}</Button>
          </div>
        </form>
      </Modal>

      <ConfirmationDialog
        isOpen={isConfirmDeleteDialogOpen}
        onClose={() => setIsConfirmDeleteDialogOpen(false)}
        onConfirm={confirmDelete}
        title="Confirm Deletion"
        message={`Are you sure you want to delete ${customerToDelete?.name}? This action cannot be undone.`}
      />
    </div>
  );
};

export default CustomersPage;
