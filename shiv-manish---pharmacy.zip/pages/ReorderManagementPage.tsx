import React, { useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { ReorderRequest, TableColumn, UserRole, ReorderStatus, EditReorderRequestPayload } from '../types';
import Table from '../components/Table';
import Button from '../components/Button';
import { format } from 'date-fns';
import { CheckCircleIcon, ClipboardListIcon, PencilIcon, XCircleIcon } from '../constants';
import ConfirmationDialog from '../components/ConfirmationDialog';
import EditReorderRequestModal from '../components/EditReorderRequestModal';

const ReorderManagementPage: React.FC = () => {
  const { state, dispatch } = useAppContext();
  const { reorderRequests, currentUser } = state;

  const [requestToConfirmComplete, setRequestToConfirmComplete] = useState<ReorderRequest | null>(null);
  const [isConfirmCompleteModalOpen, setIsConfirmCompleteModalOpen] = useState(false);

  const [requestToCancel, setRequestToCancel] = useState<ReorderRequest | null>(null);
  const [isCancelConfirmModalOpen, setIsCancelConfirmModalOpen] = useState(false);

  const [requestToEdit, setRequestToEdit] = useState<ReorderRequest | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);


  if (currentUser?.role !== UserRole.ADMIN) {
    return <div className="p-4 text-red-500">Access Denied. Only Admins can manage re-order requests.</div>;
  }

  // Mark as Completed
  const handleMarkAsCompletedClick = (request: ReorderRequest) => {
    setRequestToConfirmComplete(request);
    setIsConfirmCompleteModalOpen(true);
  };
  
  const confirmCompletion = () => {
    if (requestToConfirmComplete) {
      dispatch({
        type: 'UPDATE_REORDER_STATUS',
        payload: {
          requestId: requestToConfirmComplete.id,
          status: ReorderStatus.COMPLETED,
          adminNotes: requestToConfirmComplete.adminNotes || `Completed by ${currentUser.name}`,
        },
      });
      alert(`Re-order for ${requestToConfirmComplete.medicineName} marked as completed and stock updated.`);
    }
    setIsConfirmCompleteModalOpen(false);
    setRequestToConfirmComplete(null);
  };

  // Cancel Order
  const handleCancelOrderClick = (request: ReorderRequest) => {
    setRequestToCancel(request);
    setIsCancelConfirmModalOpen(true);
  };

  const confirmCancelOrder = () => {
    if (requestToCancel) {
      dispatch({
        type: 'UPDATE_REORDER_STATUS',
        payload: {
          requestId: requestToCancel.id,
          status: ReorderStatus.CANCELLED,
          adminNotes: requestToCancel.adminNotes ? `${requestToCancel.adminNotes}; Cancelled by ${currentUser.name}` : `Cancelled by ${currentUser.name}`,
        }
      });
      alert(`Re-order for ${requestToCancel.medicineName} has been cancelled.`);
    }
    setIsCancelConfirmModalOpen(false);
    setRequestToCancel(null);
  };

  // Edit Order
  const handleEditOrderClick = (request: ReorderRequest) => {
    setRequestToEdit(request);
    setIsEditModalOpen(true);
  };

  const handleConfirmEditOrder = (payload: EditReorderRequestPayload) => {
    dispatch({ type: 'EDIT_REORDER_REQUEST', payload });
    alert(`Re-order request ${payload.requestId} has been updated.`);
    setIsEditModalOpen(false);
    setRequestToEdit(null);
  };


  const columns: TableColumn<ReorderRequest>[] = [
    { key: 'medicineName', header: 'Medicine' },
    { key: 'supplier', header: 'Supplier', render: item => item.supplier || 'N/A' },
    { key: 'quantityOrdered', header: 'Qty Ordered' },
    { 
      key: 'requestDate', 
      header: 'Request Date', 
      render: item => format(new Date(item.requestDate), 'Pp') 
    },
    { key: 'requestedByUserName', header: 'Requested By' },
    { 
      key: 'status', 
      header: 'Status',
      render: item => (
        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
          item.status === ReorderStatus.COMPLETED ? 'bg-green-200 text-green-800' :
          item.status === ReorderStatus.PENDING ? 'bg-yellow-200 text-yellow-800' :
          item.status === ReorderStatus.CANCELLED ? 'bg-red-200 text-red-800' :
          'bg-gray-200 text-gray-800'
        }`}>
          {item.status}
        </span>
      )
    },
    { 
        key: 'completionDate', 
        header: 'Completion/Cancellation Date', 
        render: item => item.completionDate ? format(new Date(item.completionDate), 'Pp') : 'N/A' 
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (item) => {
        if (item.status === ReorderStatus.PENDING) {
          return (
            <div className="flex flex-wrap gap-2">
              <Button
                size="sm"
                variant="success"
                onClick={() => handleMarkAsCompletedClick(item)}
                leftIcon={<CheckCircleIcon className="w-4 h-4" />}
                title="Mark as Completed and Update Stock"
              >
                Complete
              </Button>
              <Button
                size="sm"
                variant="secondary"
                onClick={() => handleEditOrderClick(item)}
                leftIcon={<PencilIcon className="w-4 h-4" />}
                title="Edit Order Details"
              >
                Edit
              </Button>
              <Button
                size="sm"
                variant="danger"
                onClick={() => handleCancelOrderClick(item)}
                leftIcon={<XCircleIcon className="w-4 h-4" />}
                title="Cancel this Re-order Request"
              >
                Cancel
              </Button>
            </div>
          );
        }
        return <span className="text-sm text-gray-500">No actions available</span>;
      },
    },
  ];

  const sortedReorderRequests = [...reorderRequests].sort((a, b) => 
    new Date(b.requestDate).getTime() - new Date(a.requestDate).getTime()
  );


  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <ClipboardListIcon className="w-8 h-8 text-primary-700" />
        <h1 className="text-3xl font-semibold text-gray-800">Re-order Management</h1>
      </div>

      <Table 
        columns={columns} 
        data={sortedReorderRequests} 
        keyExtractor={(item) => item.id} 
        emptyStateMessage="No re-order requests found."
      />

      <ConfirmationDialog
        isOpen={isConfirmCompleteModalOpen}
        onClose={() => {
            setIsConfirmCompleteModalOpen(false);
            setRequestToConfirmComplete(null);
        }}
        onConfirm={confirmCompletion}
        title="Confirm Re-order Completion"
        message={`Are you sure you want to mark the re-order for ${requestToConfirmComplete?.quantityOrdered} units of "${requestToConfirmComplete?.medicineName}" (Batch: ${requestToConfirmComplete?.newBatchDetails?.batchNumber}) as completed? This will update the stock quantity and medicine batch details.`}
        confirmButtonText="Yes, Mark Completed"
      />

      <ConfirmationDialog
        isOpen={isCancelConfirmModalOpen}
        onClose={() => {
            setIsCancelConfirmModalOpen(false);
            setRequestToCancel(null);
        }}
        onConfirm={confirmCancelOrder}
        title="Confirm Re-order Cancellation"
        message={`Are you sure you want to cancel the re-order request for ${requestToCancel?.quantityOrdered} units of "${requestToCancel?.medicineName}"? This action cannot be undone.`}
        confirmButtonText="Yes, Cancel Order"
        // Fix: Removed unsupported 'variant' prop. The dialog's confirm button is already 'danger'.
      />

      {requestToEdit && (
        <EditReorderRequestModal
            isOpen={isEditModalOpen}
            onClose={() => {
                setIsEditModalOpen(false);
                setRequestToEdit(null);
            }}
            request={requestToEdit}
            onConfirmEdit={handleConfirmEditOrder}
        />
      )}
    </div>
  );
};

export default ReorderManagementPage;