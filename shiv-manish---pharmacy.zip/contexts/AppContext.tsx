
import React, { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import { User, Medicine, Customer, Bill, UserRole, ReorderRequest, ReorderStatus, AppState, AppAction, PurchaseRecord, NewBatchInfo, EditReorderRequestPayload, ArchivedReport } from '../types';
import { LOW_STOCK_THRESHOLD } from '../constants';

// Define sheet names for Excel
const SHEET_NAMES = {
    USERS: 'Users',
    MEDICINES: 'Medicines',
    CUSTOMERS: 'Customers',
    BILLS: 'Bills',
    REORDER_REQUESTS: 'ReorderRequests',
    PURCHASE_RECORDS: 'PurchaseRecords',
    ARCHIVED_REPORTS: 'ArchivedReports', // New sheet
};


const initialState: AppState = {
  currentUser: null,
  users: [
    { id: 'admin-user', username: 'admin', password: 'password', role: UserRole.ADMIN, name: 'Admin User' },
    { id: 'pharmacist-user', username: 'pharmacist', password: 'password', role: UserRole.PHARMACIST, name: 'Pharma Cist' },
    { id: 'cashier-user', username: 'cashier', password: 'password', role: UserRole.CASHIER, name: 'Cash R. User' },
  ],
  medicines: [
    { id: 'med1', name: 'Paracetamol 500mg', batchNumber: 'P500-001', manufacturer: 'Generic Pharma', supplier: 'PharmaDistro Inc.', category: 'Analgesic', expiryDate: '2025-12-31', manufacturingDate: '2023-01-01', purchasePrice: 0.8, salePrice: 1.0, quantityInStock: 100, lowStockThreshold: 20 },
    { id: 'med2', name: 'Amoxicillin 250mg', batchNumber: 'A250-002', manufacturer: 'MediCo', supplier: 'Health Supplies Ltd.', category: 'Antibiotic', expiryDate: '2025-08-15', manufacturingDate: '2023-08-16', purchasePrice: 1.5, salePrice: 2.0, quantityInStock: 5, lowStockThreshold: 10 },
    { id: 'med3', name: 'Ibuprofen 200mg', batchNumber: 'I200-003', manufacturer: 'HealthWell', supplier: 'PharmaDistro Inc.', category: 'NSAID', expiryDate: '2026-06-30', manufacturingDate: '2023-07-01', purchasePrice: 1.0, salePrice: 1.5, quantityInStock: 150, lowStockThreshold: 15 },
    { id: 'med4', name: 'Cetirizine 10mg', batchNumber: 'C10-004', manufacturer: 'Generic Pharma', supplier: 'Health Supplies Ltd.', category: 'Antihistamine', expiryDate: '2025-05-31', manufacturingDate: '2023-06-01', purchasePrice: 0.5, salePrice: 0.75, quantityInStock: 75, lowStockThreshold: 15 },
    { id: 'med5', name: 'Old Cough Syrup', batchNumber: 'OCS-001', manufacturer: 'OldPharma', supplier: 'Vintage Meds', category: 'Syrup', expiryDate: '2022-01-01', manufacturingDate: '2020-01-01', purchasePrice: 2, salePrice: 3, quantityInStock: 10, lowStockThreshold: 5 },
  ],
  customers: [
    { id: 'cust1', name: 'John Doe', contact: '555-1234', age: 35, gender: 'Male', address: '123 Main St' },
    { id: 'cust2', name: 'Jane Smith', contact: '555-5678', age: 42, gender: 'Female', address: '456 Oak Ave' },
  ],
  bills: [],
  reorderRequests: [],
  purchaseRecords: [], 
  archivedReports: [], // Initialize new state
  lowStockThreshold: LOW_STOCK_THRESHOLD
};

const appReducer = (state: AppState, action: AppAction): AppState => {
  switch (action.type) {
    case 'INITIALIZE_STATE':
      return { ...state, ...action.payload };
    case 'LOGIN':
      return { ...state, currentUser: action.payload };
    case 'LOGOUT':
      return { ...state, currentUser: null };
    // User CRUD
    case 'ADD_USER':
      return { ...state, users: [...state.users, action.payload] };
    case 'UPDATE_USER':
      return { ...state, users: state.users.map(u => u.id === action.payload.id ? action.payload : u) };
    case 'DELETE_USER':
      return { ...state, users: state.users.filter(u => u.id !== action.payload) };
    // Medicine CRUD
    case 'ADD_MEDICINE':
      return { ...state, medicines: [...state.medicines, action.payload] };
    case 'UPDATE_MEDICINE':
      return { ...state, medicines: state.medicines.map(m => m.id === action.payload.id ? action.payload : m) };
    case 'DELETE_MEDICINE':
      return { ...state, medicines: state.medicines.filter(m => m.id !== action.payload) };
    // Customer CRUD
    case 'ADD_CUSTOMER':
      return { ...state, customers: [...state.customers, action.payload] };
    case 'UPDATE_CUSTOMER':
      return { ...state, customers: state.customers.map(c => c.id === action.payload.id ? action.payload : c) };
    case 'DELETE_CUSTOMER':
      return { ...state, customers: state.customers.filter(c => c.id !== action.payload) };
    // Billing
    case 'ADD_BILL':
      return { ...state, bills: [...state.bills, action.payload] };
    case 'UPDATE_MEDICINE_STOCK': {
      return {
        ...state,
        medicines: state.medicines.map(med =>
          med.id === action.payload.medicineId
          ? { ...med, quantityInStock: Math.max(0, med.quantityInStock - action.payload.quantityChange) }
          : med
        )
      };
    }
    // Reorder Requests
    case 'ADD_REORDER_REQUEST':
      return { ...state, reorderRequests: [...state.reorderRequests, action.payload] };
    case 'UPDATE_REORDER_STATUS': {
      let newMedicines = [...state.medicines];
      let newPurchaseRecords = [...state.purchaseRecords];

      const updatedReorderRequests = state.reorderRequests.map(req => {
        if (req.id === action.payload.requestId) {
          const isCompleting = action.payload.status === ReorderStatus.COMPLETED && req.status !== ReorderStatus.COMPLETED;
          
          if (isCompleting && req.newBatchDetails) {
            const medicineIndex = newMedicines.findIndex(med => med.id === req.medicineId);
            if (medicineIndex > -1) {
              const oldMedicine = newMedicines[medicineIndex];
              const batchDetails = req.newBatchDetails;

              newMedicines[medicineIndex] = {
                ...oldMedicine,
                quantityInStock: oldMedicine.quantityInStock + req.quantityOrdered,
                batchNumber: batchDetails.batchNumber,
                manufacturingDate: batchDetails.manufacturingDate,
                expiryDate: batchDetails.expiryDate,
                purchasePrice: batchDetails.purchasePrice,
                salePrice: batchDetails.salePrice,
              };

              const purchaseRecord: PurchaseRecord = {
                id: `PR-${Date.now()}`,
                medicineId: req.medicineId,
                medicineName: req.medicineName,
                supplier: req.supplier,
                batchNumber: batchDetails.batchNumber,
                manufacturingDate: batchDetails.manufacturingDate,
                expiryDate: batchDetails.expiryDate,
                quantityPurchased: req.quantityOrdered,
                purchasePricePerUnit: batchDetails.purchasePrice,
                salePricePerUnit: batchDetails.salePrice,
                totalPurchaseCost: req.quantityOrdered * batchDetails.purchasePrice,
                purchaseDate: new Date().toISOString(),
                relatedReorderId: req.id,
                notes: `From re-order request ${req.id}`
              };
              newPurchaseRecords.push(purchaseRecord);
            }
          }
          return {
            ...req,
            status: action.payload.status,
            adminNotes: action.payload.adminNotes || req.adminNotes,
            completionDate: isCompleting ? new Date().toISOString() : (action.payload.status === ReorderStatus.CANCELLED ? new Date().toISOString() : req.completionDate),
          };
        }
        return req;
      });
      return { ...state, reorderRequests: updatedReorderRequests, medicines: newMedicines, purchaseRecords: newPurchaseRecords };
    }
    case 'EDIT_REORDER_REQUEST': {
      return {
        ...state,
        reorderRequests: state.reorderRequests.map(req => {
          if (req.id === action.payload.requestId && req.status === ReorderStatus.PENDING) {
            return {
              ...req,
              quantityOrdered: action.payload.updatedDetails.quantityOrdered ?? req.quantityOrdered,
              supplier: action.payload.updatedDetails.supplier ?? req.supplier,
              newBatchDetails: action.payload.updatedDetails.newBatchDetails ?? req.newBatchDetails,
              adminNotes: action.payload.updatedDetails.adminNotes ?? req.adminNotes,
            };
          }
          return req;
        }),
      };
    }
    // Expired Stock Management
    case 'DISPOSE_EXPIRED_STOCK':
      return {
        ...state,
        medicines: state.medicines.map(med =>
          med.id === action.payload.medicineId
            ? { ...med, quantityInStock: 0 }
            : med
        ),
      };
    case 'REPLACE_EXPIRED_BATCH': {
        return {
            ...state,
            medicines: state.medicines.map(med =>
            med.id === action.payload.medicineId
                ? {
                    ...med, 
                    batchNumber: action.payload.details.batchNumber,
                    manufacturingDate: action.payload.details.manufacturingDate,
                    expiryDate: action.payload.details.expiryDate,
                    purchasePrice: action.payload.details.purchasePrice,
                    salePrice: action.payload.details.salePrice,
                    quantityInStock: action.payload.details.newQuantityInStock,
                }
                : med
            ),
        };
    }
    // Purchase Records
    case 'ADD_PURCHASE_RECORD':
        return { ...state, purchaseRecords: [...state.purchaseRecords, action.payload] };
    // Archived Reports
    case 'ADD_ARCHIVED_REPORT':
        return { ...state, archivedReports: [...state.archivedReports, action.payload] };
    default:
      return state;
  }
};

const AppContext = createContext<{ state: AppState; dispatch: React.Dispatch<AppAction> } | undefined>(undefined);

// Helper function to safely parse JSON and provide defaults
const parseSheetData = <T,>(sheetData: any[], defaultObject: T, customizer?: (item: any) => Partial<T>): T[] => {
    if (!Array.isArray(sheetData)) return [];
    return sheetData.map(item => {
        const customizedItem = customizer ? customizer(item) : {};
        return { ...defaultObject, ...item, ...customizedItem } as T;
    });
};


export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState);
  const [dataFilePath, setDataFilePath] = React.useState<string | null>(localStorage.getItem('pharmaDataFilePath'));
  const [isDataLoaded, setIsDataLoaded] = React.useState(false);
  // Fix: Changed NodeJS.Timeout to ReturnType<typeof setTimeout>
  const [saveTimeout, setSaveTimeout] = React.useState<ReturnType<typeof setTimeout> | null>(null);


  const loadDataFromExcelAndInitialize = React.useCallback(async (filePath: string) => {
    // @ts-ignore
    if (!window.electronAPI || !window.electronAPI.readExcelFile) {
        console.error("Electron API for reading Excel files is not available.");
        // Fallback or error display
        alert("Error: Application components for file access are missing. Please restart or check installation.");
        setIsDataLoaded(true); // Prevent reload loops
        return;
    }
    try {
        // @ts-ignore
        const excelData = await window.electronAPI.readExcelFile(filePath);
        if (excelData && typeof excelData === 'object' && Object.keys(excelData).length > 0) {
            const parsedState: Partial<AppState> = {};
            
            // Helper to parse nested JSON strings
            const parseJsonField = (item: any, fieldName: string) => {
                if (item[fieldName] && typeof item[fieldName] === 'string') {
                    try {
                        return JSON.parse(item[fieldName]);
                    } catch (e) { console.warn(`Failed to parse JSON for ${fieldName} in item:`, item); return undefined;}
                }
                return item[fieldName];
            };

            if (excelData[SHEET_NAMES.USERS]) parsedState.users = parseSheetData(excelData[SHEET_NAMES.USERS], initialState.users[0] || {} as User);
            if (excelData[SHEET_NAMES.MEDICINES]) parsedState.medicines = parseSheetData(excelData[SHEET_NAMES.MEDICINES], initialState.medicines[0] || {} as Medicine);
            if (excelData[SHEET_NAMES.CUSTOMERS]) parsedState.customers = parseSheetData(excelData[SHEET_NAMES.CUSTOMERS], initialState.customers[0] || {} as Customer);
            
            if (excelData[SHEET_NAMES.BILLS]) {
                parsedState.bills = parseSheetData(excelData[SHEET_NAMES.BILLS], initialState.bills[0] || {} as Bill, bill => ({
                    items: parseJsonField(bill, 'items') || []
                }));
            }
            if (excelData[SHEET_NAMES.REORDER_REQUESTS]) {
                 parsedState.reorderRequests = parseSheetData(excelData[SHEET_NAMES.REORDER_REQUESTS], initialState.reorderRequests[0] || {} as ReorderRequest, req => ({
                    newBatchDetails: parseJsonField(req, 'newBatchDetails')
                }));
            }
            if (excelData[SHEET_NAMES.PURCHASE_RECORDS]) parsedState.purchaseRecords = parseSheetData(excelData[SHEET_NAMES.PURCHASE_RECORDS], initialState.purchaseRecords[0] || {} as PurchaseRecord);
            if (excelData[SHEET_NAMES.ARCHIVED_REPORTS]) parsedState.archivedReports = parseSheetData(excelData[SHEET_NAMES.ARCHIVED_REPORTS], {} as ArchivedReport);


            // Ensure critical structures like currentUser are handled
            const storedUser = localStorage.getItem('pharmaCurrentUser');
            if(storedUser) parsedState.currentUser = JSON.parse(storedUser);
            else parsedState.currentUser = null;
            
            parsedState.lowStockThreshold = excelData.Settings?.[0]?.lowStockThreshold || initialState.lowStockThreshold;

            dispatch({ type: 'INITIALIZE_STATE', payload: parsedState });
            console.log('State initialized from Excel:', filePath);
        } else {
             // File is empty or invalid, initialize with default state and save it
            console.log('Excel file is empty or invalid, initializing with default state and saving.');
            dispatch({ type: 'INITIALIZE_STATE', payload: initialState }); // Use full initial state
            // await saveStateToExcel(filePath, initialState); // Save the initial state to the new file
        }
    } catch (error) {
        console.error("Failed to load or parse data from Excel:", error);
        alert(`Error loading data file ${filePath}. It might be corrupted or inaccessible. Starting with a blank state. Please check the console for details.`);
        // Potentially prompt to select a new file or start fresh
        localStorage.removeItem('pharmaDataFilePath');
        setDataFilePath(null);
        dispatch({ type: 'INITIALIZE_STATE', payload: initialState }); // Reset to ensure app is usable
    } finally {
        setIsDataLoaded(true);
    }
  }, [dispatch]);


  const saveStateToExcel = React.useCallback(async (filePath: string, currentState: AppState) => {
    // @ts-ignore
    if (!window.electronAPI || !window.electronAPI.writeExcelFile) {
        console.error("Electron API for writing Excel files is not available.");
        return;
    }

    const dataToSave: { [sheetName: string]: any[] } = {};

    // Remove passwords before saving users
    dataToSave[SHEET_NAMES.USERS] = currentState.users.map(u => { const { password, ...userWithoutPass } = u; return userWithoutPass; });
    dataToSave[SHEET_NAMES.MEDICINES] = currentState.medicines;
    dataToSave[SHEET_NAMES.CUSTOMERS] = currentState.customers;
    
    // Stringify nested objects for Bills and ReorderRequests
    dataToSave[SHEET_NAMES.BILLS] = currentState.bills.map(bill => ({
        ...bill,
        items: JSON.stringify(bill.items) // Store items as JSON string
    }));
    dataToSave[SHEET_NAMES.REORDER_REQUESTS] = currentState.reorderRequests.map(req => ({
        ...req,
        newBatchDetails: req.newBatchDetails ? JSON.stringify(req.newBatchDetails) : undefined
    }));
    dataToSave[SHEET_NAMES.PURCHASE_RECORDS] = currentState.purchaseRecords;
    dataToSave[SHEET_NAMES.ARCHIVED_REPORTS] = currentState.archivedReports;


    // Save settings like lowStockThreshold (example)
    // dataToSave['Settings'] = [{ lowStockThreshold: currentState.lowStockThreshold }];
    try {
        // @ts-ignore
        await window.electronAPI.writeExcelFile({ filePath, data: dataToSave });
        console.log('State saved to Excel:', filePath);
    } catch (error) {
        console.error("Failed to save state to Excel:", error);
        alert("Error saving data. Please check console for details.");
    }
  }, []);


  const promptForDataFileAndInitialize = React.useCallback(async () => {
    // @ts-ignore
    if (!window.electronAPI) {
        alert("File system API not available. App cannot load/save data.");
        setIsDataLoaded(true); 
        return;
    }
    const choice = window.confirm("Data file not found or not configured. Do you want to select an existing 'ShivManish_PharmacyData.xlsx' file? Click 'Cancel' to create a new one.");
    let filePathToUse: string | null = null;

    if (choice) { // User wants to select an existing file
        try {
            // @ts-ignore
            const result = await window.electronAPI.showOpenDialog({
                title: "Select ShivManish Pharmacy Data File",
                defaultPath: "ShivManish_PharmacyData.xlsx",
                filters: [{ name: 'Excel Files', extensions: ['xlsx'] }],
                properties: ['openFile']
            });
            if (result && !result.canceled && result.filePaths.length > 0) {
                filePathToUse = result.filePaths[0];
            } else {
                alert("No file selected. A new data file will be created.");
            }
        } catch (e) { console.error("Error opening file dialog", e); }
    }

    if (!filePathToUse) { // Create a new file
        try {
            // @ts-ignore
            const result = await window.electronAPI.showSaveDialog({
                title: "Create New ShivManish Pharmacy Data File",
                defaultPath: "ShivManish_PharmacyData.xlsx",
                filters: [{ name: 'Excel Files', extensions: ['xlsx'] }]
            });
            if (result && !result.canceled && result.filePath) {
                filePathToUse = result.filePath;
                // Save the initial (demo) state to this new file immediately
                await saveStateToExcel(filePathToUse, initialState); 
                dispatch({ type: 'INITIALIZE_STATE', payload: initialState }); // Also init in-memory state
            } else {
                alert("File creation cancelled. Application will run with temporary data (not saved).");
                setIsDataLoaded(true); // Allow app to run with in-memory initial state
                return;
            }
        } catch (e) { 
            console.error("Error opening save dialog", e); 
            alert("Could not create data file. App will run with temporary data.");
            setIsDataLoaded(true);
            return;
        }
    }
    
    if (filePathToUse) {
        localStorage.setItem('pharmaDataFilePath', filePathToUse);
        setDataFilePath(filePathToUse);
        await loadDataFromExcelAndInitialize(filePathToUse);
    } else {
        setIsDataLoaded(true); // Fallback if all else fails
    }
  }, [loadDataFromExcelAndInitialize, saveStateToExcel]);


  useEffect(() => { // Effect for initial data load
    if (!dataFilePath) {
        promptForDataFileAndInitialize();
    } else {
        loadDataFromExcelAndInitialize(dataFilePath);
    }
  }, [dataFilePath, loadDataFromExcelAndInitialize, promptForDataFileAndInitialize]);


  useEffect(() => { // Effect for saving data on state change
    if (isDataLoaded && dataFilePath) {
        if (saveTimeout) clearTimeout(saveTimeout);
        
        const newTimeout = setTimeout(() => {
            // Save current user to localStorage separately as it's session-specific
            if (state.currentUser) {
                localStorage.setItem('pharmaCurrentUser', JSON.stringify(state.currentUser));
            } else {
                localStorage.removeItem('pharmaCurrentUser');
            }
            saveStateToExcel(dataFilePath, state);
        }, 1000); // Debounce save operation
        setSaveTimeout(newTimeout);
    }
    // Cleanup timeout on unmount
    return () => {
        if (saveTimeout) clearTimeout(saveTimeout);
    };
  }, [state, dataFilePath, isDataLoaded, saveStateToExcel, saveTimeout]);


  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {isDataLoaded ? children : <div>Loading application data...</div>}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
